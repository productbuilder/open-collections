import { createLocalProvider } from '../../../packages/provider-local/src/index.js';
import { createPublicUrlProvider } from '../../../packages/provider-public-url/src/index.js';
import { createGithubProvider } from '../../../packages/provider-github/src/index.js';
import {
  createGoogleDriveProvider,
  normalizeGoogleDriveManifestUrl,
  requestGoogleDriveAccessToken,
} from '../../../packages/provider-gdrive/src/index.js';
import { COLLECTOR_CONFIG } from './config.js';
import { createOpfsStorage } from './services/opfs_storage.js';
import { createInitialState } from './state/initial-state.js';
import { makeSourceId, toWorkspaceItemId } from './utils/id-utils.js';
import {
  slugifySegment as slugifySegmentUtil,
  hostNameFromPath as hostNameFromPathUtil,
  normalizeCollectionRootPath as normalizeCollectionRootPathUtil,
  joinCollectionRootPath as joinCollectionRootPathUtil,
} from './utils/path-utils.js';
import { renderShell } from './render/render-shell.js';
import * as RenderAssets from './render/render-assets.js';
import * as RenderEditor from './render/render-editor.js';
import * as RenderViewer from './render/render-viewer.js';
import * as RenderSourceUI from './render/render-source-ui.js';
import * as AssetService from './services/asset-service.js';
import * as CollectionService from './services/collection-service.js';
import * as ManifestService from './services/manifest-service.js';
import * as DraftService from './services/draft-service.js';

const SOURCES_STORAGE_KEY = 'timemap_collector_sources_v1';
const COLLECTIONS_DIR_PATH = 'collections';
const SOURCES_DIR_PATH = 'sources';
const DRAFT_ASSETS_DIR_PATH = 'draft-assets';

class OpenCollectionsManagerElement extends HTMLElement {
  constructor() {
    super();

    this.state = createInitialState();

    this.opfsStorage = createOpfsStorage();
    this._autosaveTimer = null;
    this.localAssetBlobs = new Map();
    this.objectUrls = new Set();

    this.providerFactories = {
      local: createLocalProvider(),
      'public-url': createPublicUrlProvider(),
      github: createGithubProvider(),
      gdrive: createGoogleDriveProvider(),
    };

    this.providers = {
      local: createLocalProvider,
      'public-url': createPublicUrlProvider,
      github: createGithubProvider,
      gdrive: createGoogleDriveProvider,
    };

    this.providerCatalog = [
      {
        ...this.providerFactories.github.getDescriptor(),
        label: 'GitHub repository',
        description: 'Writable storage source for managed collections (recommended).',
      },
      {
        ...this.providerFactories.gdrive.getDescriptor(),
        label: 'Google Drive',
        description: 'Connected Drive source (currently read-only import for managed collections).',
      },
      {
        id: 's3',
        label: 'S3-compatible storage',
        category: 'external',
        enabled: false,
        statusLabel: 'Coming soon',
        description: 'Writable object storage source for institutional collection management.',
      },
      {
        id: 'wordpress',
        label: 'WordPress / CMS',
        category: 'external',
        enabled: false,
        statusLabel: 'Planned',
        description: 'Manage collections linked to CMS-managed media libraries.',
      },
      {
        id: 'wikimedia',
        label: 'Wikimedia Commons',
        category: 'external',
        enabled: false,
        statusLabel: 'Planned',
        description: 'Import media and metadata from Wikimedia Commons.',
      },
      {
        id: 'internet-archive',
        label: 'Internet Archive',
        category: 'external',
        enabled: false,
        statusLabel: 'Planned',
        description: 'Browse and load assets from Archive.org items.',
      },
      this.providerFactories.local.getDescriptor(),
    ];

    this.shadow = this.attachShadow({ mode: 'open' });
    this.renderShell();
    this.cacheDom();
    this.editorViews = {
      none: this.dom.editorEmpty,
      collection: this.dom.collectionEditorForm,
      item: this.dom.editorForm,
    };
  }

  connectedCallback() {
    this.bindEvents();
    this.setStatus('No hosts connected yet.', 'neutral');
    this.setConnectionStatus('No hosts connected.', 'neutral');
    this.renderCapabilities(this.providerFactories.local.getCapabilities());
    this.renderProviderCatalog();
    this.setSelectedProvider('github');
    this.renderSourcesList();
    this.renderSourceFilter();
    this.renderAssets();
    this.renderEditor();
    this.renderWorkspaceContext();
    this.renderSourceContext();
    this.setLocalDraftStatus('Checking local draft storage...', 'neutral');
    this.setLocalDraftControlsEnabled(false);
    this.initializeLocalDraftState();
    this.syncEditorVisibility();
    this._handleWindowResize = () => this.syncEditorVisibility();
    window.addEventListener('resize', this._handleWindowResize);
  }

  disconnectedCallback() {
    if (this._handleWindowResize) {
      window.removeEventListener('resize', this._handleWindowResize);
      this._handleWindowResize = null;
    }
  }

  renderShell() {
    renderShell(this.shadow);
  }

  cacheDom() {
    const root = this.shadow;
    this.dom = {
      statusText: root.getElementById('statusText'),
      workspaceContext: root.getElementById('workspaceContext'),
      openHostManagerBtn: root.getElementById('openHostManagerBtn'),
      openHeaderMenuBtn: root.getElementById('openHeaderMenuBtn'),
      activeHostLabel: root.getElementById('activeHostLabel'),
      backToCollectionsBtn: root.getElementById('backToCollectionsBtn'),
      viewportTitle: root.getElementById('viewportTitle'),
      editorPanel: root.querySelector('.editor-panel'),
      editorTitle: root.getElementById('editorTitle'),
      editorContent: root.getElementById('editorContent'),
      closeEditorBtn: root.getElementById('closeEditorBtn'),
      providerDialog: root.getElementById('providerDialog'),
      sourcePickerDialog: root.getElementById('sourcePickerDialog'),
      sourcePickerList: root.getElementById('sourcePickerList'),
      publishDialog: root.getElementById('publishDialog'),
      newCollectionDialog: root.getElementById('newCollectionDialog'),
      registerDialog: root.getElementById('registerDialog'),
      headerMenuDialog: root.getElementById('headerMenuDialog'),
      openRegisterFromMenuBtn: root.getElementById('openRegisterFromMenuBtn'),
      storageOptionsDialog: root.getElementById('storageOptionsDialog'),
      assetViewerDialog: root.getElementById('assetViewerDialog'),
      closeViewerBtn: root.getElementById('closeViewerBtn'),
      viewerTitle: root.getElementById('viewerTitle'),
      viewerMedia: root.getElementById('viewerMedia'),
      viewerDescription: root.getElementById('viewerDescription'),
      viewerBadges: root.getElementById('viewerBadges'),
      viewerOpenOriginal: root.getElementById('viewerOpenOriginal'),
      providerCatalog: root.getElementById('providerCatalog'),
      sourceList: root.getElementById('sourceList'),
      openStorageOptionsBtn: root.getElementById('openStorageOptionsBtn'),
      sourceFilter: root.getElementById('sourceFilter'),
      collectionFilter: root.getElementById('collectionFilter'),
      providerConfigTitle: root.getElementById('providerConfigTitle'),
      githubConfig: root.getElementById('githubConfig'),
      githubToken: root.getElementById('githubToken'),
      githubOwner: root.getElementById('githubOwner'),
      githubRepo: root.getElementById('githubRepo'),
      githubBranch: root.getElementById('githubBranch'),
      githubPath: root.getElementById('githubPath'),
      publicUrlConfig: root.getElementById('publicUrlConfig'),
      publicUrlInput: root.getElementById('publicUrlInput'),
      gdriveConfig: root.getElementById('gdriveConfig'),
      gdriveSourceMode: root.getElementById('gdriveSourceMode'),
      gdriveAuthConfig: root.getElementById('gdriveAuthConfig'),
      gdrivePublicConfig: root.getElementById('gdrivePublicConfig'),
      gdriveUrlInput: root.getElementById('gdriveUrlInput'),
      gdriveClientIdInput: root.getElementById('gdriveClientIdInput'),
      gdriveFileIdInput: root.getElementById('gdriveFileIdInput'),
      gdriveConnectAuthBtn: root.getElementById('gdriveConnectAuthBtn'),
      gdriveAccessTokenInput: root.getElementById('gdriveAccessTokenInput'),
      gdriveAuthStatus: root.getElementById('gdriveAuthStatus'),
      localConfig: root.getElementById('localConfig'),
      localPathInput: root.getElementById('localPathInput'),
      placeholderConfig: root.getElementById('placeholderConfig'),
      connectBtn: root.getElementById('connectBtn'),
      connectionStatus: root.getElementById('connectionStatus'),
      capabilities: root.getElementById('capabilities'),
      assetCount: root.getElementById('assetCount'),
      addImagesBtn: root.getElementById('addImagesBtn'),
      imageFileInput: root.getElementById('imageFileInput'),
      assetWrap: root.getElementById('assetWrap'),
      assetDropOverlay: root.getElementById('assetDropOverlay'),
      assetGrid: root.getElementById('assetGrid'),
      editorContext: root.getElementById('editorContext'),
      editorEmpty: root.getElementById('editorEmpty'),
      collectionEditorForm: root.getElementById('collectionEditorForm'),
      editorForm: root.getElementById('editorForm'),
      itemTitle: root.getElementById('itemTitle'),
      itemDescription: root.getElementById('itemDescription'),
      itemType: root.getElementById('itemType'),
      itemCreator: root.getElementById('itemCreator'),
      itemDate: root.getElementById('itemDate'),
      itemLocation: root.getElementById('itemLocation'),
      itemLicense: root.getElementById('itemLicense'),
      itemAttribution: root.getElementById('itemAttribution'),
      itemSource: root.getElementById('itemSource'),
      itemTags: root.getElementById('itemTags'),
      itemInclude: root.getElementById('itemInclude'),
      saveItemBtn: root.getElementById('saveItemBtn'),
      collectionEditorTitle: root.getElementById('collectionEditorTitle'),
      collectionEditorDescription: root.getElementById('collectionEditorDescription'),
      collectionEditorLicense: root.getElementById('collectionEditorLicense'),
      collectionEditorPublisher: root.getElementById('collectionEditorPublisher'),
      collectionEditorLanguage: root.getElementById('collectionEditorLanguage'),
      saveCollectionBtn: root.getElementById('saveCollectionBtn'),
      collectionId: root.getElementById('collectionId'),
      collectionTitle: root.getElementById('collectionTitle'),
      collectionDescription: root.getElementById('collectionDescription'),
      collectionLicense: root.getElementById('collectionLicense'),
      collectionPublisher: root.getElementById('collectionPublisher'),
      collectionLanguage: root.getElementById('collectionLanguage'),
      newCollectionTitle: root.getElementById('newCollectionTitle'),
      newCollectionSlug: root.getElementById('newCollectionSlug'),
      newCollectionDescription: root.getElementById('newCollectionDescription'),
      newCollectionLicense: root.getElementById('newCollectionLicense'),
      newCollectionPublisher: root.getElementById('newCollectionPublisher'),
      newCollectionLanguage: root.getElementById('newCollectionLanguage'),
      createCollectionBtn: root.getElementById('createCollectionBtn'),
      generateManifestBtn: root.getElementById('generateManifestBtn'),
      publishToSourceBtn: root.getElementById('publishToSourceBtn'),
      copyManifestBtn: root.getElementById('copyManifestBtn'),
      downloadManifestBtn: root.getElementById('downloadManifestBtn'),
      saveLocalDraftBtn: root.getElementById('saveLocalDraftBtn'),
      restoreLocalDraftBtn: root.getElementById('restoreLocalDraftBtn'),
      discardLocalDraftBtn: root.getElementById('discardLocalDraftBtn'),
      localDraftStatus: root.getElementById('localDraftStatus'),
      manifestPreview: root.getElementById('manifestPreview'),
    };

    this.dom.localPathInput.value = COLLECTOR_CONFIG.defaultLocalManifestPath;
    this.dom.gdriveClientIdInput.value = COLLECTOR_CONFIG.googleDriveOAuth?.clientId || '';
    this.dom.collectionId.value = COLLECTOR_CONFIG.defaultCollectionMeta.id;
    this.dom.collectionTitle.value = COLLECTOR_CONFIG.defaultCollectionMeta.title;
    this.dom.collectionDescription.value = COLLECTOR_CONFIG.defaultCollectionMeta.description;
    this.dom.collectionLicense.value = '';
    this.dom.collectionPublisher.value = '';
    this.dom.collectionLanguage.value = '';
    this.dom.manifestPreview.textContent = '{}';
  }

  bindEvents() {
    if (this._eventsBound) {
      return;
    }

    this._eventsBound = true;

    this.dom.openHostManagerBtn.addEventListener('click', () => this.openDialog(this.dom.providerDialog));
    this.dom.openHeaderMenuBtn.addEventListener('click', () => this.openDialog(this.dom.headerMenuDialog));
    this.dom.openStorageOptionsBtn.addEventListener('click', () => this.openDialog(this.dom.storageOptionsDialog));
    this.dom.openRegisterFromMenuBtn.addEventListener('click', () => {
      this.closeDialog(this.dom.headerMenuDialog);
      this.openDialog(this.dom.registerDialog);
    });
    this.dom.backToCollectionsBtn.addEventListener('click', () => this.leaveCollectionView());
    this.dom.closeEditorBtn.addEventListener('click', () => this.closeMobileEditor());
    this.dom.closeViewerBtn.addEventListener('click', () => this.closeViewer());
    this.dom.assetViewerDialog.addEventListener('close', () => {
      this.state.viewerItemId = null;
    });
    this.dom.assetViewerDialog.addEventListener('cancel', () => {
      this.state.viewerItemId = null;
    });
    this.dom.sourceFilter.addEventListener('change', () => {
      this.state.activeSourceFilter = this.dom.sourceFilter.value || 'all';
      this.state.selectedCollectionId = 'all';
      const visible = this.getVisibleAssets();
      if (this.state.selectedItemId && !visible.some((item) => item.workspaceId === this.state.selectedItemId)) {
        this.state.selectedItemId = visible[0]?.workspaceId || null;
      }
      this.renderCollectionFilter();
      this.state.currentLevel = 'collections';
      this.state.metadataMode = 'collection';
      this.state.openedCollectionId = null;
      this.closeMobileEditor();
      this.renderSourceContext();
      this.renderAssets();
      this.renderEditor();
      if (this.state.opfsAvailable) {
        this.persistWorkspaceToOpfs().catch(() => {});
      }
    });
    this.dom.collectionFilter.addEventListener('change', () => {
      this.state.selectedCollectionId = this.dom.collectionFilter.value || 'all';
      this.state.metadataMode = this.state.currentLevel === 'collections' ? 'collection' : 'item';
      const visible = this.getVisibleAssets();
      if (this.state.selectedItemId && !visible.some((item) => item.workspaceId === this.state.selectedItemId)) {
        this.state.selectedItemId = visible[0]?.workspaceId || null;
      }
      this.renderAssets();
      this.renderEditor();
      if (this.state.opfsAvailable) {
        this.persistWorkspaceToOpfs().catch(() => {});
      }
    });

    this.shadow.querySelectorAll('[data-close]').forEach((button) => {
      button.addEventListener('click', () => {
        const dialogId = button.getAttribute('data-close');
        this.closeDialog(this.shadow.getElementById(dialogId));
      });
    });

    this.dom.connectBtn.addEventListener('click', async () => {
      await this.connectCurrentProvider();
    });

    this.dom.gdriveSourceMode.addEventListener('change', () => {
      this.renderGoogleDriveMode();
    });

    this.dom.gdriveConnectAuthBtn.addEventListener('click', async () => {
      await this.connectGoogleDriveAuth();
    });
    this.dom.newCollectionTitle.addEventListener('input', () => {
      const currentSlug = (this.dom.newCollectionSlug.value || '').trim();
      if (!currentSlug) {
        this.dom.newCollectionSlug.value = this.slugifySegment(this.dom.newCollectionTitle.value.trim(), 'new-collection');
      }
    });
    this.dom.createCollectionBtn.addEventListener('click', async () => {
      await this.createNewCollectionDraft();
    });

    this.dom.saveItemBtn.addEventListener('click', async () => {
      const selected = this.findSelectedItem();
      if (!selected) {
        return;
      }
      await this.updateItem(selected.workspaceId, this.collectEditorPatch(), { explicitSave: true });
    });

    this.dom.saveCollectionBtn.addEventListener('click', async () => {
      await this.saveSelectedCollectionMetadata();
    });

    this.dom.generateManifestBtn.addEventListener('click', async () => {
      await this.generateManifest();
    });

    this.dom.copyManifestBtn.addEventListener('click', async () => {
      await this.copyManifestToClipboard();
    });

    this.dom.downloadManifestBtn.addEventListener('click', () => {
      this.downloadManifest();
    });
    this.dom.publishToSourceBtn.addEventListener('click', async () => {
      await this.publishActiveSourceDraft();
    });
    this.dom.addImagesBtn.addEventListener('click', () => {
      if (this.state.currentLevel === 'collections') {
        this.openNewCollectionDialog();
        return;
      }
      this.dom.imageFileInput.click();
    });
    this.dom.imageFileInput.addEventListener('change', async (event) => {
      const files = Array.from(event.target?.files || []);
      if (files.length > 0) {
        await this.ingestImageFiles(files);
      }
      this.dom.imageFileInput.value = '';
    });
    this.dom.assetWrap.addEventListener('dragenter', (event) => {
      event.preventDefault();
      this.setDropTargetState(true);
    });
    this.dom.assetWrap.addEventListener('dragover', (event) => {
      event.preventDefault();
      this.setDropTargetState(true);
    });
    this.dom.assetWrap.addEventListener('dragleave', (event) => {
      event.preventDefault();
      if (!event.relatedTarget || !this.dom.assetWrap.contains(event.relatedTarget)) {
        this.setDropTargetState(false);
      }
    });
    this.dom.assetWrap.addEventListener('drop', async (event) => {
      event.preventDefault();
      this.setDropTargetState(false);
      const files = Array.from(event.dataTransfer?.files || []);
      if (files.length > 0) {
        await this.ingestImageFiles(files);
      }
    });
    this.dom.saveLocalDraftBtn.addEventListener('click', async () => {
      await this.saveLocalDraft();
    });
    this.dom.restoreLocalDraftBtn.addEventListener('click', async () => {
      await this.restoreLocalDraft();
    });
    this.dom.discardLocalDraftBtn.addEventListener('click', async () => {
      await this.discardLocalDraft();
    });
  }

  openDialog(dialog) {
    if (!dialog) {
      return;
    }

    if (dialog.open) {
      return;
    }

    if (typeof dialog.showModal === 'function') {
      dialog.showModal();
      return;
    }

    dialog.setAttribute('open', 'open');
  }

  closeDialog(dialog) {
    if (!dialog) {
      return;
    }

    if (!dialog.open) {
      return;
    }

    if (typeof dialog.close === 'function') {
      dialog.close();
      return;
    }

    dialog.removeAttribute('open');
  }

  isMobileViewport() {
    return typeof window !== 'undefined' && window.matchMedia('(max-width: 760px)').matches;
  }

  openMobileEditor() {
    this.state.mobileEditorOpen = true;
    this.syncEditorVisibility();
  }

  closeMobileEditor() {
    this.state.mobileEditorOpen = false;
    this.syncEditorVisibility();
  }

  syncEditorVisibility() {
    if (!this.dom?.editorPanel) {
      return;
    }
    const shouldShowOverlay = this.isMobileViewport() && this.state.mobileEditorOpen;
    this.dom.editorPanel.classList.toggle('is-mobile-editor-open', shouldShowOverlay);
  }

  renderProviderCatalog() {
    this.dom.providerCatalog.innerHTML = '';

    for (const entry of this.providerCatalog) {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'provider-card';
      button.dataset.providerId = entry.id;
      button.disabled = entry.enabled === false;

      if (entry.enabled === false) {
        button.classList.add('is-disabled');
      }

      if (this.state.selectedProviderId === entry.id) {
        button.classList.add('is-selected');
      }

      button.innerHTML = `
        <div class="provider-card-label-row">
          <strong>${entry.label}</strong>
          <span class="pill ${entry.enabled === false ? 'is-muted' : ''}">${entry.statusLabel || 'Available'}</span>
        </div>
        <span class="panel-subtext">${entry.description || ''}</span>
      `;

      button.addEventListener('click', () => {
        if (entry.enabled === false) {
          return;
        }
        this.setSelectedProvider(entry.id);
      });

      this.dom.providerCatalog.appendChild(button);
    }
  }

  setSelectedProvider(providerId) {
    const selected = this.providerCatalog.find((entry) => entry.id === providerId);
    if (!selected) {
      return;
    }

    this.state.selectedProviderId = providerId;

    this.shadow.querySelectorAll('.provider-card').forEach((card) => {
      card.classList.toggle('is-selected', card.dataset.providerId === providerId);
    });

    this.dom.providerConfigTitle.textContent = `${selected.label} host configuration`;
    this.dom.githubConfig.classList.add('is-hidden');
    this.dom.publicUrlConfig.classList.add('is-hidden');
    this.dom.gdriveConfig.classList.add('is-hidden');
    this.dom.localConfig.classList.add('is-hidden');
    this.dom.placeholderConfig.classList.add('is-hidden');

    if (providerId === 'github') {
      this.dom.githubConfig.classList.remove('is-hidden');
    } else if (providerId === 'gdrive') {
      this.dom.gdriveConfig.classList.remove('is-hidden');
      this.renderGoogleDriveMode();
    } else if (providerId === 'public-url') {
      this.dom.publicUrlConfig.classList.remove('is-hidden');
    } else if (providerId === 'local') {
      this.dom.localConfig.classList.remove('is-hidden');
    } else {
      this.dom.placeholderConfig.classList.remove('is-hidden');
    }

    this.dom.connectBtn.disabled = selected.enabled === false;
    this.renderCapabilities(this.providerFactories[providerId]?.getCapabilities?.() || selected.capabilities || {});
  }

  renderGoogleDriveMode() {
    const mode = this.dom.gdriveSourceMode.value || 'auth-manifest-file';
    const isAuthMode = mode === 'auth-manifest-file';
    this.dom.gdriveAuthConfig.classList.toggle('is-hidden', !isAuthMode);
    this.dom.gdrivePublicConfig.classList.toggle('is-hidden', isAuthMode);
    if (isAuthMode) {
      if (!this.dom.gdriveAuthStatus.textContent.trim()) {
        this.dom.gdriveAuthStatus.textContent = 'Disconnected.';
      }
    } else {
      this.dom.gdriveAuthStatus.textContent = 'Public shared URL mode selected.';
      this.dom.gdriveAccessTokenInput.value = '';
    }

    if (this.state.selectedProviderId === 'gdrive') {
      this.renderCapabilities({
        canListAssets: true,
        canGetAsset: true,
        canSaveMetadata: false,
        canExportCollection: true,
        authRequired: isAuthMode,
      });
    }
  }

  setGoogleDriveAuthStatus(text, tone = 'neutral') {
    const colors = {
      neutral: '#64748b',
      ok: '#166534',
      warn: '#9a3412',
    };
    this.dom.gdriveAuthStatus.textContent = text;
    this.dom.gdriveAuthStatus.style.color = colors[tone] || colors.neutral;
  }

  async connectGoogleDriveAuth() {
    const sourceMode = this.dom.gdriveSourceMode.value || 'auth-manifest-file';
    if (sourceMode !== 'auth-manifest-file') {
      this.setGoogleDriveAuthStatus('Switch to authenticated mode to connect Google Drive.', 'warn');
      return;
    }

    const clientId = this.dom.gdriveClientIdInput.value.trim();
    if (!clientId) {
      this.setGoogleDriveAuthStatus('Enter a Google OAuth Client ID to start authentication.', 'warn');
      return;
    }

    this.setGoogleDriveAuthStatus('Connecting to Google Drive...', 'neutral');

    try {
      const tokenResult = await requestGoogleDriveAccessToken({
        clientId,
        scope: COLLECTOR_CONFIG.googleDriveOAuth?.scope || 'https://www.googleapis.com/auth/drive.readonly',
      });

      this.dom.gdriveAccessTokenInput.value = tokenResult.accessToken || '';
      this.setGoogleDriveAuthStatus('Connected. Access token is loaded for this session.', 'ok');
      this.setConnectionStatus('Google Drive authentication completed for this session.', 'ok');
      this.setStatus('Google Drive authenticated. Add source to load the selected manifest file.', 'ok');
    } catch (error) {
      this.setGoogleDriveAuthStatus(error.message, 'warn');
      this.setConnectionStatus(`Google Drive auth failed: ${error.message}`, 'warn');
      this.setStatus(`Google Drive auth failed: ${error.message}`, 'warn');
    }
  }

  setStatus(text, tone = 'neutral') {
    const colors = {
      neutral: '#64748b',
      ok: '#166534',
      warn: '#9a3412',
    };

    this.dom.statusText.textContent = text;
    this.dom.statusText.style.color = colors[tone] || colors.neutral;
  }

  setConnectionStatus(text, tone = false) {
    const resolvedTone = typeof tone === 'boolean' ? (tone ? 'ok' : 'warn') : tone;
    const colors = {
      neutral: '#64748b',
      ok: '#166534',
      warn: '#9a3412',
    };

    this.dom.connectionStatus.textContent = text;
    this.dom.connectionStatus.style.color = colors[resolvedTone] || colors.neutral;
  }

  setLocalDraftStatus(text, tone = 'neutral') {
    const colors = {
      neutral: '#64748b',
      ok: '#166534',
      warn: '#9a3412',
    };
    this.state.opfsStatus = text;
    if (this.dom?.localDraftStatus) {
      this.dom.localDraftStatus.textContent = text;
      this.dom.localDraftStatus.style.color = colors[tone] || colors.neutral;
    }
  }

  setLocalDraftControlsEnabled(enabled) {
    const disabled = !enabled;
    if (this.dom?.saveLocalDraftBtn) {
      this.dom.saveLocalDraftBtn.disabled = disabled;
      this.dom.restoreLocalDraftBtn.disabled = disabled;
      this.dom.discardLocalDraftBtn.disabled = disabled;
    }
  }

  draftCollectionId() {
    return (
      this.dom.collectionId.value.trim() ||
      COLLECTOR_CONFIG.defaultCollectionMeta.id ||
      'collection-draft'
    );
  }

  draftFilePath(collectionId = this.draftCollectionId()) {
    return `${COLLECTIONS_DIR_PATH}/${collectionId}.json`;
  }

  sourceFilePath(sourceId) {
    return `${SOURCES_DIR_PATH}/${sourceId}.json`;
  }

  setDropTargetState(active) {
    this.state.isDropTargetActive = Boolean(active);
    if (this.dom?.assetDropOverlay) {
      this.dom.assetDropOverlay.classList.toggle('is-active', this.state.isDropTargetActive);
    }
  }

  isSupportedImageFile(file) {
    if (!file) {
      return false;
    }
    const mime = (file.type || '').toLowerCase();
    if (mime.startsWith('image/jpeg') || mime.startsWith('image/png') || mime.startsWith('image/webp') || mime.startsWith('image/gif')) {
      return true;
    }
    return /\.(jpe?g|png|webp|gif)$/i.test(file.name || '');
  }

  toWorkspaceItemId(sourceId, itemId) {
    return toWorkspaceItemId(sourceId, itemId);
  }

  slugifySegment(value, fallback = 'item') {
    return slugifySegmentUtil(value, fallback);
  }

  hostNameFromPath(path, fallback = 'Local host') {
    return hostNameFromPathUtil(path, fallback);
  }

  normalizeCollectionRootPath(rootPath, fallbackId = '') {
    return normalizeCollectionRootPathUtil(rootPath, fallbackId);
  }

  joinCollectionRootPath(collectionRootPath, relativePath = '') {
    return joinCollectionRootPathUtil(
      collectionRootPath,
      relativePath,
      this.state.selectedCollectionId || 'collection',
    );
  }

  activeCollectionRootPath() {
    const collectionId = (this.state.selectedCollectionId || '').trim();
    if (!collectionId || collectionId === 'all') {
      return '';
    }
    const activeSource = this.state.activeSourceFilter !== 'all' ? this.getSourceById(this.state.activeSourceFilter) : null;
    if (activeSource) {
      const sourceCollection = (activeSource.collections || []).find((entry) => entry.id === collectionId);
      if (sourceCollection?.rootPath) {
        return this.normalizeCollectionRootPath(sourceCollection.rootPath, collectionId);
      }
    }
    const localCollection = this.state.localDraftCollections.find((entry) => entry.id === collectionId);
    if (localCollection?.rootPath) {
      return this.normalizeCollectionRootPath(localCollection.rootPath, collectionId);
    }
    return this.normalizeCollectionRootPath(`${collectionId}/`, collectionId);
  }

  renderWorkspaceContext() {
    const source =
      this.state.activeSourceFilter !== 'all'
        ? this.getSourceById(this.state.activeSourceFilter)
        : null;
    const sourceLabel = source?.displayLabel || source?.label || 'none';
    const collectionId = this.state.selectedCollectionId && this.state.selectedCollectionId !== 'all'
      ? this.state.selectedCollectionId
      : 'none';
    const rootPath = collectionId !== 'none' ? this.activeCollectionRootPath() : 'n/a';
    this.dom.workspaceContext.textContent = `Host: ${sourceLabel} | Collection: ${collectionId} | Root: ${rootPath}`;
  }

  readableTitleFromFilename(name, fallbackId) {
    const base = String(name || '').replace(/\.[^.]+$/, '');
    const cleaned = base.replace(/[_-]+/g, ' ').trim();
    return cleaned || fallbackId;
  }

  openNewCollectionDialog() {
    this.dom.newCollectionTitle.value = '';
    this.dom.newCollectionSlug.value = '';
    this.dom.newCollectionDescription.value = '';
    this.dom.newCollectionLicense.value = '';
    this.dom.newCollectionPublisher.value = '';
    this.dom.newCollectionLanguage.value = '';
    this.openDialog(this.dom.newCollectionDialog);
  }

  setCollectionMetaFields(meta = {}) {
    this.dom.collectionId.value = meta.id || this.dom.collectionId.value;
    this.dom.collectionTitle.value = meta.title || this.dom.collectionTitle.value;
    this.dom.collectionDescription.value = meta.description || '';
    this.dom.collectionLicense.value = meta.license || '';
    this.dom.collectionPublisher.value = meta.publisher || '';
    this.dom.collectionLanguage.value = meta.language || '';
  }

  collectionIdExists(collectionId) {
    return CollectionService.collectionIdExists(this, collectionId);
  }

  ensureUniqueCollectionId(baseId) {
    return CollectionService.ensureUniqueCollectionId(this, baseId);
  }

  buildInitialCollectionManifest(meta) {
    return CollectionService.buildInitialCollectionManifest(this, meta);
  }

  async createNewCollectionDraft() {
    return CollectionService.createNewCollectionDraft(this);
  }

  extensionFromName(name = '', fallback = '.jpg') {
    const match = String(name).toLowerCase().match(/\.[a-z0-9]+$/);
    return match ? match[0] : fallback;
  }

  uniqueDraftItemId(base, sourceId, collectionId) {
    const existing = new Set(
      this.state.assets
        .filter((item) => item.sourceId === sourceId && item.collectionId === collectionId)
        .map((item) => item.id),
    );
    if (!existing.has(base)) {
      return base;
    }
    let index = 2;
    while (existing.has(`${base}-${index}`)) {
      index += 1;
    }
    return `${base}-${index}`;
  }

  getActiveIngestionSource() {
    if (!this.state.sources.length) {
      this.setStatus('Connect a writable storage source before adding images.', 'warn');
      return null;
    }

    if (this.state.activeSourceFilter === 'all') {
      this.setStatus('Select a specific storage source before adding images.', 'warn');
      return null;
    }

    const source = this.getSourceById(this.state.activeSourceFilter);
    if (!source) {
      this.setStatus('Selected storage source was not found.', 'warn');
      return null;
    }

    if (source.providerId !== 'github') {
      this.setStatus('Image upload publishing is currently implemented for GitHub sources only.', 'warn');
      return null;
    }

    if (source.needsReconnect || source.needsCredentials) {
      this.setStatus('Reconnect the selected GitHub source before adding local draft assets.', 'warn');
      return null;
    }

    return source;
  }

  ensureCollectionForSource(source) {
    const preferred = (this.state.selectedCollectionId || '').trim();
    const existing = source.collections || [];
    if (preferred && preferred !== 'all') {
      if (!existing.some((entry) => entry.id === preferred)) {
        const localEntry = this.state.localDraftCollections.find((entry) => entry.id === preferred);
        source.collections = [
          ...existing,
          {
            id: preferred,
            title: localEntry?.title || preferred,
            rootPath: this.normalizeCollectionRootPath(localEntry?.rootPath || `${preferred}/`, preferred),
          },
        ];
      }
      source.selectedCollectionId = preferred;
      return preferred;
    }

    if (source.selectedCollectionId && existing.some((entry) => entry.id === source.selectedCollectionId)) {
      return source.selectedCollectionId;
    }

    const first = existing[0]?.id;
    if (first) {
      source.selectedCollectionId = first;
      return first;
    }

    const fallback = `${source.id}::default-collection`;
    source.collections = [{ id: fallback, title: source.displayLabel || source.label || 'Default collection' }];
    source.selectedCollectionId = fallback;
    return fallback;
  }

  collectionLabelFor(source, collectionId) {
    const found = (source.collections || []).find((entry) => entry.id === collectionId);
    return found?.title || collectionId;
  }

  collectionAssetPath(workspaceId, kind = 'original', extension = '.jpg') {
    return `${DRAFT_ASSETS_DIR_PATH}/${workspaceId}/${kind}${extension}`;
  }

  registerObjectUrl(url) {
    if (url) {
      this.objectUrls.add(url);
    }
  }

  async generateThumbnailBlob(file) {
    return AssetService.generateThumbnailBlob(this, file);
  }

  async rememberLocalAssetFiles(item, originalBlob, thumbnailBlob) {
    return AssetService.rememberLocalAssetFiles(this, item, originalBlob, thumbnailBlob);
  }

  async loadLocalAssetBlob(item, kind = 'original') {
    return AssetService.loadLocalAssetBlob(this, item, kind);
  }

  async rehydrateLocalDraftAssetUrls() {
    return AssetService.rehydrateLocalDraftAssetUrls(this);
  }

  refreshSourceCollectionsAndCounts(sourceId) {
    const source = this.getSourceById(sourceId);
    if (!source) {
      return;
    }
    const sourceAssets = this.state.assets.filter((item) => item.sourceId === sourceId);
    source.collections = this.buildCollectionsForSource(source, sourceAssets);
    source.itemCount = sourceAssets.length;
    if (!source.collections.some((entry) => entry.id === source.selectedCollectionId)) {
      source.selectedCollectionId = source.collections[0]?.id || null;
    }
  }

  async ingestImageFiles(files) {
    return AssetService.ingestImageFiles(this, files);
  }

  renderCapabilities(capabilitiesOrProvider) {
    const capabilities =
      typeof capabilitiesOrProvider?.getCapabilities === 'function'
        ? capabilitiesOrProvider.getCapabilities()
        : capabilitiesOrProvider || {};
    this.dom.capabilities.textContent = JSON.stringify(capabilities, null, 2);
  }

  getSourceById(sourceId) {
    return this.state.sources.find((entry) => entry.id === sourceId) || null;
  }

  getVisibleAssets() {
    let visible = this.state.assets;
    if (this.state.activeSourceFilter !== 'all') {
      visible = visible.filter((item) => item.sourceId === this.state.activeSourceFilter);
    }
    if (this.state.selectedCollectionId !== 'all') {
      visible = visible.filter((item) => item.collectionId === this.state.selectedCollectionId);
    }
    return visible;
  }

  renderSourceFilter() {
    return RenderSourceUI.renderSourceFilter(this);
  }

  renderCollectionFilter() {
    return RenderSourceUI.renderCollectionFilter(this);
  }

  formatSourceBadge(item) {
    const display = (item.sourceDisplayLabel || '').trim();
    if (display) {
      return display;
    }
    const providerName = this.providerCatalog.find((entry) => entry.id === item.providerId)?.label || item.providerId || '';
    return providerName || 'Source';
  }

  renderSourcesList() {
    return RenderSourceUI.renderSourcesList(this);
  }

  collectCurrentProviderConfig(providerId) {
    const config = {};

    if (providerId === 'local') {
      config.path = this.dom.localPathInput.value.trim() || COLLECTOR_CONFIG.defaultLocalManifestPath;
    }

    if (providerId === 'public-url') {
      config.manifestUrl = this.dom.publicUrlInput.value.trim();
    }

    if (providerId === 'gdrive') {
      config.sourceMode = this.dom.gdriveSourceMode.value || 'auth-manifest-file';
      config.manifestUrl = this.dom.gdriveUrlInput.value.trim();
      config.fileId = this.dom.gdriveFileIdInput.value.trim();
      config.accessToken = this.dom.gdriveAccessTokenInput.value.trim();
      config.oauthClientId = this.dom.gdriveClientIdInput.value.trim();
      config.oauthScopes = COLLECTOR_CONFIG.googleDriveOAuth?.scope || 'https://www.googleapis.com/auth/drive.readonly';
    }

    if (providerId === 'github') {
      config.token = this.dom.githubToken.value;
      config.owner = this.dom.githubOwner.value;
      config.repo = this.dom.githubRepo.value;
      config.branch = this.dom.githubBranch.value;
      config.path = this.dom.githubPath.value;
    }

    return config;
  }

  sourceDisplayLabelFor(providerId, config, fallbackLabel) {
    if (providerId === 'github') {
      const repo = (config.repo || '').trim();
      return repo || 'GitHub';
    }

    if (providerId === 'public-url') {
      const manifestUrl = (config.manifestUrl || '').trim();
      if (!manifestUrl) {
        return 'Public URL';
      }

      try {
        const parsed = new URL(manifestUrl);
        const parts = parsed.pathname.split('/').filter(Boolean);
        if (parsed.hostname.includes('githubusercontent.com') && parts.length >= 2) {
          return parts[1];
        }

        const file = parts[parts.length - 1] || '';
        const name = file.replace(/\.[^.]+$/, '');
        if (name && !['collection', 'manifest', 'index'].includes(name.toLowerCase())) {
          return name;
        }

        return parsed.hostname.replace(/^www\./i, '') || 'Public URL';
      } catch (error) {
        return 'Public URL';
      }
    }

    if (providerId === 'gdrive') {
      const manifestTitle = (config._manifestTitle || '').trim();
      if (manifestTitle) {
        return manifestTitle;
      }
      if ((config.sourceMode || '') === 'auth-manifest-file') {
        return 'Google Drive (Auth)';
      }
      return 'Google Drive';
    }

    if (providerId === 'local') {
      return this.hostNameFromPath(config.path, 'Local host');
    }

    return fallbackLabel || 'Source';
  }

  sourceDetailLabelFor(providerId, config, fallbackLabel) {
    if (providerId === 'github') {
      const owner = (config.owner || '').trim();
      const repo = (config.repo || '').trim();
      const path = (config.path || '').trim();
      const branch = (config.branch || 'main').trim() || 'main';
      const base = owner && repo ? `${owner}/${repo}` : fallbackLabel;
      const scope = path || '/';
      return `${base} @ ${branch}:${scope}`;
    }

    if (providerId === 'public-url') {
      return (config.manifestUrl || '').trim() || 'Public URL manifest';
    }

    if (providerId === 'gdrive') {
      const fileId = (config._normalizedFileId || config.fileId || '').trim();
      const mode = (config.sourceMode || '').trim() || 'public-manifest-url';
      if (fileId) {
        return mode === 'auth-manifest-file' ? `Google Drive API file ${fileId}` : `Google Drive file ${fileId}`;
      }
      return mode === 'auth-manifest-file' ? 'Google Drive API manifest' : 'Google Drive manifest';
    }

    if (providerId === 'local') {
      return (config.path || '').trim() || 'Local host';
    }

    return fallbackLabel || 'Source';
  }

  sanitizeSourceConfig(providerId, config = {}) {
    if (providerId === 'github') {
      return {
        owner: (config.owner || '').trim(),
        repo: (config.repo || '').trim(),
        branch: (config.branch || 'main').trim() || 'main',
        path: (config.path || '').trim(),
      };
    }

    if (providerId === 'public-url') {
      return {
        manifestUrl: (config.manifestUrl || '').trim(),
      };
    }

    if (providerId === 'gdrive') {
      return {
        sourceMode: (config.sourceMode || 'public-manifest-url').trim() || 'public-manifest-url',
        manifestUrl: (config.manifestUrl || '').trim(),
        fileId: (config.fileId || '').trim(),
        oauthClientId: (config.oauthClientId || '').trim(),
      };
    }

    if (providerId === 'local') {
      return {
        path: (config.path || '').trim() || COLLECTOR_CONFIG.defaultLocalManifestPath,
      };
    }

    return {};
  }

  toPersistedSource(source) {
    return {
      id: source.id,
      providerId: source.providerId,
      providerLabel: source.providerLabel,
      displayLabel: source.displayLabel || source.label,
      detailLabel: source.detailLabel || source.label,
      config: this.sanitizeSourceConfig(source.providerId, source.config),
      capabilities: source.capabilities || {},
      authMode: source.authMode || 'public',
      itemCount: source.itemCount || 0,
      status: source.status || '',
      needsReconnect: Boolean(source.needsReconnect),
      needsCredentials: Boolean(source.needsCredentials),
    };
  }

  currentWorkspaceSnapshot() {
    return {
      selectedSourceId: this.state.activeSourceFilter || 'all',
      selectedCollectionId: this.state.selectedCollectionId || 'all',
      selectedItemId: this.state.selectedItemId || null,
      collectionMeta: this.currentCollectionMeta(),
      draftCollectionId: this.draftCollectionId(),
      lastLocalSaveAt: this.state.lastLocalSaveAt || '',
      localDraftCollections: this.state.localDraftCollections || [],
    };
  }

  buildLocalDraftPayload() {
    return {
      savedAt: new Date().toISOString(),
      collectionMeta: this.currentCollectionMeta(),
      manifest: this.state.manifest || null,
      selectedItemId: this.state.selectedItemId || null,
      selectedSourceId: this.state.activeSourceFilter || 'all',
      selectedCollectionId: this.state.selectedCollectionId || 'all',
      localDraftCollections: this.state.localDraftCollections || [],
      assets: this.state.assets.map((item) => ({
        ...item,
        previewUrl: '',
        thumbnailPreviewUrl: '',
        draftUploadStatus: item.draftUploadStatus === 'uploading' ? 'pending-upload' : item.draftUploadStatus,
        workspaceId: item.workspaceId,
        sourceId: item.sourceId,
        sourceAssetId: item.sourceAssetId,
        sourceLabel: item.sourceLabel,
        sourceDisplayLabel: item.sourceDisplayLabel,
        providerId: item.providerId,
        collectionId: item.collectionId || null,
        collectionLabel: item.collectionLabel || '',
      })),
      sources: this.state.sources.map((source) => this.toPersistedSource(source)),
    };
  }

  async persistSourcesToOpfs(payload) {
    return DraftService.persistSourcesToOpfs(this, payload);
  }

  async persistWorkspaceToOpfs(extra = {}) {
    return DraftService.persistWorkspaceToOpfs(this, extra);
  }

  async loadRememberedSourcesFromOpfs() {
    return DraftService.loadRememberedSourcesFromOpfs(this);
  }

  applyWorkspaceSnapshot(snapshot = {}) {
    if (!snapshot || typeof snapshot !== 'object') {
      return;
    }
    if (Array.isArray(snapshot.localDraftCollections)) {
      this.state.localDraftCollections = snapshot.localDraftCollections
        .filter((entry) => entry && entry.id)
        .map((entry) => ({
          id: String(entry.id),
          title: entry.title || String(entry.id),
          rootPath: this.normalizeCollectionRootPath(entry.rootPath || `${entry.id}/`, entry.id),
        }));
    }

    if (snapshot.collectionMeta && typeof snapshot.collectionMeta === 'object') {
      this.setCollectionMetaFields({
        id: snapshot.collectionMeta.id || this.dom.collectionId.value,
        title: snapshot.collectionMeta.title || this.dom.collectionTitle.value,
        description: snapshot.collectionMeta.description || this.dom.collectionDescription.value,
        license: snapshot.collectionMeta.license || this.dom.collectionLicense.value,
        publisher: snapshot.collectionMeta.publisher || this.dom.collectionPublisher.value,
        language: snapshot.collectionMeta.language || this.dom.collectionLanguage.value,
      });
    }

    if (snapshot.selectedSourceId && (snapshot.selectedSourceId === 'all' || this.state.sources.some((entry) => entry.id === snapshot.selectedSourceId))) {
      this.state.activeSourceFilter = snapshot.selectedSourceId;
    }
    this.renderSourceFilter();

    if (snapshot.selectedCollectionId) {
      this.state.selectedCollectionId = snapshot.selectedCollectionId;
      this.renderCollectionFilter();
    }

    if (
      snapshot.selectedItemId &&
      this.state.assets.some((entry) => entry.workspaceId === snapshot.selectedItemId)
    ) {
      this.state.selectedItemId = snapshot.selectedItemId;
    }
  }

  saveSourcesToStorage() {
    const payload = this.state.sources.map((source) => this.toPersistedSource(source));

    try {
      window.localStorage.setItem(SOURCES_STORAGE_KEY, JSON.stringify(payload));
    } catch (error) {
      // Ignore storage failures in restricted/private browser modes.
    }

    if (!this.state.opfsAvailable) {
      return;
    }

    this.persistSourcesToOpfs(payload)
      .then(() => this.persistWorkspaceToOpfs())
      .catch((error) => {
        this.setLocalDraftStatus(`Local draft save failed: ${error.message}`, 'warn');
      });
  }

  async restoreRememberedSources() {
    let remembered = [];

    if (this.state.opfsAvailable) {
      try {
        remembered = await this.loadRememberedSourcesFromOpfs();
      } catch (error) {
        remembered = [];
      }
    }

    if (!Array.isArray(remembered) || remembered.length === 0) {
      try {
        remembered = JSON.parse(window.localStorage.getItem(SOURCES_STORAGE_KEY) || '[]');
      } catch (error) {
        remembered = [];
      }
    }

    if (!Array.isArray(remembered) || remembered.length === 0) {
      return;
    }

    const restored = remembered
      .filter((entry) => entry && typeof entry === 'object')
      .map((entry) => ({
        id: entry.id || makeSourceId(entry.providerId || 'source'),
        providerId: entry.providerId,
        providerLabel: entry.providerLabel || this.providerCatalog.find((p) => p.id === entry.providerId)?.label || 'Source',
        displayLabel: entry.displayLabel || entry.label || 'Source',
        detailLabel: entry.detailLabel || entry.label || 'Source',
        label: entry.detailLabel || entry.label || entry.displayLabel || 'Source',
        config: this.sanitizeSourceConfig(entry.providerId, entry.config || {}),
        capabilities: entry.capabilities || this.providerFactories[entry.providerId]?.getCapabilities?.() || {},
        status: (() => {
          if (entry.providerId === 'github') {
            return 'Remembered storage source. Token is not stored; re-enter token if repository requires it.';
          }
          if (entry.providerId === 'gdrive' && entry.config?.sourceMode === 'auth-manifest-file') {
            return 'Remembered storage source. Google access token is session-only; reconnect authentication before refresh.';
          }
          return 'Remembered storage source. Click Refresh to reconnect.';
        })(),
        authMode:
          entry.providerId === 'github'
            ? 'token'
            : entry.providerId === 'gdrive' && entry.config?.sourceMode === 'auth-manifest-file'
              ? 'google-auth'
              : entry.authMode || 'public',
        itemCount: Number(entry.itemCount) || 0,
        provider: null,
        needsReconnect: true,
        needsCredentials: entry.providerId === 'github' || (entry.providerId === 'gdrive' && entry.config?.sourceMode === 'auth-manifest-file'),
      }));

    this.state.sources = restored;
    this.state.assets = [];
    this.state.selectedItemId = null;
    this.state.activeSourceFilter = 'all';
    this.state.currentLevel = 'collections';
    this.state.metadataMode = 'collection';
    this.closeMobileEditor();

    this.setStatus(`Restored ${restored.length} remembered storage source definitions.`, 'neutral');
    this.setConnectionStatus('Remembered storage sources loaded. Refresh to reconnect.', 'neutral');
    this.renderSourcesList();
    this.renderSourceFilter();
    this.renderAssets();
    this.renderEditor();

    for (const source of restored) {
      if (
        source.providerId !== 'github' &&
        !(source.providerId === 'gdrive' && source.config?.sourceMode === 'auth-manifest-file')
      ) {
        // Non-secret sources can reconnect automatically.
        await this.refreshSource(source.id);
      }
    }
  }

  async initializeLocalDraftState() {
    return DraftService.initializeLocalDraftState(this);
  }

  async saveLocalDraft() {
    return DraftService.saveLocalDraft(this);
  }

  applyLocalDraftPayload(payload) {
    if (!payload || typeof payload !== 'object') {
      return;
    }
    if (Array.isArray(payload.localDraftCollections)) {
      this.state.localDraftCollections = payload.localDraftCollections
        .filter((entry) => entry && entry.id)
        .map((entry) => ({
          id: String(entry.id),
          title: entry.title || String(entry.id),
          rootPath: this.normalizeCollectionRootPath(entry.rootPath || `${entry.id}/`, entry.id),
        }));
    }

    if (payload.collectionMeta && typeof payload.collectionMeta === 'object') {
      this.setCollectionMetaFields({
        id: payload.collectionMeta.id || this.dom.collectionId.value,
        title: payload.collectionMeta.title || this.dom.collectionTitle.value,
        description: payload.collectionMeta.description || this.dom.collectionDescription.value,
        license: payload.collectionMeta.license || this.dom.collectionLicense.value,
        publisher: payload.collectionMeta.publisher || this.dom.collectionPublisher.value,
        language: payload.collectionMeta.language || this.dom.collectionLanguage.value,
      });
    }

    if (Array.isArray(payload.assets)) {
      this.state.assets = payload.assets.map((item) => ({ ...item }));
      for (const source of this.state.sources) {
        this.refreshSourceCollectionsAndCounts(source.id);
      }
      this.renderSourcesList();
    }

    if (payload.manifest && typeof payload.manifest === 'object') {
      this.state.manifest = payload.manifest;
      this.dom.manifestPreview.textContent = JSON.stringify(payload.manifest, null, 2);
    }

    if (payload.selectedSourceId) {
      this.state.activeSourceFilter = payload.selectedSourceId;
    }
    this.renderSourceFilter();

    if (payload.selectedCollectionId) {
      this.state.selectedCollectionId = payload.selectedCollectionId;
      this.renderCollectionFilter();
    }

    if (
      payload.selectedItemId &&
      this.state.assets.some((entry) => entry.workspaceId === payload.selectedItemId)
    ) {
      this.state.selectedItemId = payload.selectedItemId;
    }

    this.renderAssets();
    this.renderEditor();
  }

  async restoreLocalDraft(options = {}) {
    return DraftService.restoreLocalDraft(this, options);
  }

  async discardLocalDraft() {
    return DraftService.discardLocalDraft(this);
  }

  normalizeSourceAssets(source, rawItems) {
    return (rawItems || []).map((item) => {
      const sourceAssetId = item.id;
      return {
        ...item,
        workspaceId: toWorkspaceItemId(source.id, sourceAssetId),
        sourceAssetId,
        sourceId: source.id,
        sourceLabel: source.label,
        sourceDisplayLabel: source.displayLabel || source.label,
        providerId: source.providerId,
        collectionId: item.collectionId || null,
        collectionLabel: item.collectionLabel || '',
        collectionRootPath: item.collectionRootPath || '',
      };
    });
  }

  buildCollectionsForSource(source, normalizedAssets) {
    const grouped = new Map();
    for (const item of normalizedAssets) {
      const collectionId = (item.collectionId || '').trim();
      const collectionLabel = (item.collectionLabel || '').trim();
      if (!collectionId) {
        continue;
      }
      if (!grouped.has(collectionId)) {
        grouped.set(collectionId, {
          id: collectionId,
          title: collectionLabel || collectionId,
          rootPath: this.normalizeCollectionRootPath(item.collectionRootPath || `${collectionId}/`, collectionId),
        });
      }
    }

    if (grouped.size > 0) {
      return Array.from(grouped.values());
    }

    const fallbackId = `${source.id}::default-collection`;
    return [
      {
        id: fallbackId,
        title: source.displayLabel || source.providerLabel || 'Default collection',
        rootPath: this.normalizeCollectionRootPath(`${fallbackId}/`, fallbackId),
      },
    ];
  }

  mergeSourceAssets(sourceId, nextItems) {
    const withoutSource = this.state.assets.filter((item) => item.sourceId !== sourceId);
    this.state.assets = [...withoutSource, ...nextItems];
  }

  requiredFieldScore(item) {
    return RenderAssets.requiredFieldScore(item);
  }

  createPreviewNode(item) {
    return RenderAssets.createPreviewNode(this, item);
  }

  openViewer(itemId) {
    return RenderViewer.openViewer(this, itemId);
  }

  closeViewer() {
    return RenderViewer.closeViewer(this);
  }

  renderViewer() {
    return RenderViewer.renderViewer(this);
  }

  renderSourceContext() {
    return RenderSourceUI.renderSourceContext(this);
  }

  renderSourcePicker() {
    return RenderSourceUI.renderSourcePicker(this);
  }

  findSelectedCollectionMeta() {
    const id = this.state.selectedCollectionId;
    if (!id || id === 'all') {
      return null;
    }
    if (this.state.activeSourceFilter !== 'all') {
      const source = this.getSourceById(this.state.activeSourceFilter);
      const found = source?.collections?.find((entry) => entry.id === id);
      if (found) return found;
    }
    return this.state.localDraftCollections.find((entry) => entry.id === id) || null;
  }

  openCollectionView(collectionId) {
    return CollectionService.openCollectionView(this, collectionId);
  }

  leaveCollectionView() {
    return CollectionService.leaveCollectionView(this);
  }

  async saveSelectedCollectionMetadata() {
    return CollectionService.saveSelectedCollectionMetadata(this);
  }

  renderAssets() {
    return RenderAssets.renderAssets(this);
  }

  selectItem(itemId) {
    if (this.state.selectedItemId === itemId) {
      if (this.isMobileViewport()) {
        this.openMobileEditor();
      }
      return;
    }

    this.state.selectedItemId = itemId;
    this.state.metadataMode = 'item';
    this.renderAssets();
    this.renderEditor();
    if (this.isMobileViewport()) {
      this.openMobileEditor();
    }
    if (this.state.opfsAvailable) {
      this.persistWorkspaceToOpfs().catch(() => {});
    }
  }

  findSelectedItem() {
    return this.state.assets.find((item) => item.workspaceId === this.state.selectedItemId) || null;
  }

  renderMetadataMode(mode) {
    return RenderEditor.renderMetadataMode(this, mode);
  }

  renderEditor() {
    return RenderEditor.renderEditor(this);
  }

  tagsToArray(rawValue) {
    return rawValue
      .split(',')
      .map((entry) => entry.trim())
      .filter(Boolean);
  }

  collectEditorPatch() {
    return {
      title: this.dom.itemTitle.value.trim(),
      description: this.dom.itemDescription.value.trim(),
      creator: this.dom.itemCreator.value.trim(),
      date: this.dom.itemDate.value.trim(),
      location: this.dom.itemLocation.value.trim(),
      license: this.dom.itemLicense.value.trim(),
      attribution: this.dom.itemAttribution.value.trim(),
      source: this.dom.itemSource.value.trim(),
      tags: this.tagsToArray(this.dom.itemTags.value),
      include: this.dom.itemInclude.checked,
      media: {
        type: this.dom.itemType.value.trim(),
      },
    };
  }

  async updateItem(id, patch, options = {}) {
    const current = this.state.assets.find((item) => item.workspaceId === id);
    if (!current) {
      this.setStatus(`Could not find item ${id}`, 'warn');
      return;
    }

    const source = this.getSourceById(current.sourceId);
    const canSave = Boolean(source?.capabilities?.canSaveMetadata) && !current.isLocalDraftAsset;

    if (canSave && source?.provider) {
      try {
        this.setStatus('Saving metadata...', 'neutral');
        const updated = await source.provider.saveMetadata(current.sourceAssetId, patch);
        if (!updated) {
          this.setStatus(`Save failed: provider returned no updated item for ${current.id}`, 'warn');
          return;
        }

        const next = {
          ...updated,
          workspaceId: current.workspaceId,
          sourceAssetId: updated.id || current.sourceAssetId,
          sourceId: current.sourceId,
          sourceLabel: current.sourceLabel,
          sourceDisplayLabel: current.sourceDisplayLabel,
          providerId: current.providerId,
        };
        this.state.assets = this.state.assets.map((item) => (item.workspaceId === id ? next : item));
        this.setStatus('Metadata saved to GitHub.', 'ok');
      } catch (error) {
        this.state.assets = this.state.assets.map((item) => {
          if (item.workspaceId !== id) {
            return item;
          }
          return {
            ...item,
            ...patch,
            media: {
              ...(item.media || {}),
              ...(patch.media || {}),
            },
          };
        });
        this.setStatus(`Save failed: ${error.message}. Local edits were kept.`, 'warn');
      }
    } else {
      this.state.assets = this.state.assets.map((item) => {
        if (item.workspaceId !== id) {
          return item;
        }
        return {
          ...item,
          ...patch,
          media: {
            ...(item.media || {}),
            ...(patch.media || {}),
          },
        };
      });
      this.setStatus('Source is read-only. Changes are local to this workspace session.', 'warn');
    }

    if (options.explicitSave && !canSave) {
      if (current.isLocalDraftAsset) {
        this.setStatus('Local draft metadata saved. Publish to upload this asset.', 'ok');
      } else {
        this.setStatus('Selected item source is read-only. Changes are local only.', 'warn');
      }
    }

    this.renderAssets();
    this.renderEditor();
  }

  async connectCurrentProvider() {
    const providerId = this.state.selectedProviderId;
    const providerFactory = this.providers[providerId];
    const selectedProvider = this.providerCatalog.find((entry) => entry.id === providerId);

    if (!providerFactory || selectedProvider?.enabled === false) {
      this.setConnectionStatus('Selected storage source type is not yet available.', false);
      this.setStatus('Selected storage source type is not yet available.', 'warn');
      return;
    }

    const provider = providerFactory();
    const config = this.collectCurrentProviderConfig(providerId);

    if (providerId === 'gdrive' && config.sourceMode === 'public-manifest-url' && config.manifestUrl) {
      const normalized = normalizeGoogleDriveManifestUrl(config.manifestUrl);
      if (!normalized.ok) {
        this.setConnectionStatus(normalized.message || 'Invalid Google Drive file URL.', false);
        this.setStatus(normalized.message || 'Invalid Google Drive file URL.', 'warn');
        return;
      }
    }

    try {
      const result = await provider.connect(config);
      this.renderCapabilities(provider);

      if (!result.ok) {
        this.setConnectionStatus(result.message, false);
        this.setStatus(result.message, 'warn');
        this.renderAssets();
        this.renderEditor();
        return;
      }

      this.setConnectionStatus(result.message, true);

      const loaded = await provider.listAssets();
      const derivedConfig = { ...config };
      if (providerId === 'gdrive') {
        derivedConfig._manifestTitle = result.sourceDisplayLabel || '';
        derivedConfig._normalizedFileId = result.fileId || '';
        derivedConfig._normalizedManifestUrl = result.normalizedManifestUrl || '';
      }
      const displayLabel =
        result.sourceDisplayLabel ||
        this.sourceDisplayLabelFor(providerId, derivedConfig, selectedProvider?.label || providerId);
      const detailLabel =
        result.sourceDetailLabel ||
        this.sourceDetailLabelFor(providerId, derivedConfig, selectedProvider?.label || providerId);
      const source = {
        id: makeSourceId(providerId),
        providerId,
        providerLabel: selectedProvider?.label || providerId,
        label: detailLabel,
        displayLabel,
        detailLabel,
        config: { ...config, ...(providerId === 'gdrive' ? { fileId: result.fileId || '' } : {}) },
        capabilities: provider.getCapabilities(),
        status: result.message,
        authMode:
          providerId === 'github'
            ? (config.token || '').trim()
              ? 'token'
              : 'public'
            : providerId === 'gdrive' && config.sourceMode === 'auth-manifest-file'
              ? 'google-auth'
              : 'public',
        itemCount: loaded.length,
        provider,
        needsReconnect: false,
        needsCredentials: providerId === 'gdrive' && config.sourceMode === 'auth-manifest-file' ? !(config.accessToken || '').trim() : false,
        collections: [],
        selectedCollectionId: null,
      };

      const normalized = this.normalizeSourceAssets(source, loaded);
      const collections = this.buildCollectionsForSource(source, normalized);
      const defaultCollectionId = collections[0]?.id || null;
      const normalizedWithCollections = normalized.map((item) => ({
        ...item,
        collectionId: item.collectionId || defaultCollectionId,
        collectionLabel: item.collectionLabel || collections.find((entry) => entry.id === (item.collectionId || defaultCollectionId))?.title || '',
      }));
      source.collections = collections;
      source.selectedCollectionId = defaultCollectionId;
      this.state.sources = [...this.state.sources, source];
      this.state.assets = [...this.state.assets, ...normalizedWithCollections];
      this.state.activeSourceFilter = source.id;
      this.state.selectedCollectionId = source.selectedCollectionId || 'all';
      this.state.currentLevel = 'collections';
      this.state.metadataMode = 'collection';
      this.state.openedCollectionId = null;
      this.closeMobileEditor();
      this.state.manifest = null;
      this.dom.manifestPreview.textContent = '{}';

      if (!this.state.selectedItemId) {
        this.state.selectedItemId = normalizedWithCollections[0]?.workspaceId || null;
      }

      this.setStatus(`Added storage source ${source.label} (${loaded.length} items).`, 'ok');
      this.renderSourcesList();
      this.renderSourceFilter();
      this.renderAssets();
      this.renderEditor();
      this.saveSourcesToStorage();
    } catch (error) {
      this.setConnectionStatus(`Connection error: ${error.message}`, false);
      this.setStatus(`Connection error: ${error.message}`, 'warn');
    }
  }

  inspectSource(sourceId) {
    const source = this.getSourceById(sourceId);
    if (!source) {
      return;
    }

    this.setSelectedProvider(source.providerId);
    if (source.providerId === 'github') {
      this.dom.githubToken.value = source.config.token || '';
      this.dom.githubOwner.value = source.config.owner || '';
      this.dom.githubRepo.value = source.config.repo || '';
      this.dom.githubBranch.value = source.config.branch || 'main';
      this.dom.githubPath.value = source.config.path || '';
    }
    if (source.providerId === 'public-url') {
      this.dom.publicUrlInput.value = source.config.manifestUrl || '';
    }
    if (source.providerId === 'gdrive') {
      this.dom.gdriveSourceMode.value = source.config.sourceMode || 'public-manifest-url';
      this.dom.gdriveUrlInput.value = source.config.manifestUrl || '';
      this.dom.gdriveFileIdInput.value = source.config.fileId || '';
      this.dom.gdriveClientIdInput.value = source.config.oauthClientId || COLLECTOR_CONFIG.googleDriveOAuth?.clientId || '';
      this.dom.gdriveAccessTokenInput.value = '';
      this.renderGoogleDriveMode();
      this.setGoogleDriveAuthStatus(
        source.config.sourceMode === 'auth-manifest-file'
          ? 'Re-authentication required before refresh.'
          : 'Public shared URL mode selected.',
        source.config.sourceMode === 'auth-manifest-file' ? 'warn' : 'neutral',
      );
    }
    if (source.providerId === 'local') {
      this.dom.localPathInput.value = source.config.path || COLLECTOR_CONFIG.defaultLocalManifestPath;
    }

    this.setConnectionStatus(`Inspecting storage source: ${source.label}`, true);
  }

  async refreshSource(sourceId) {
    const source = this.getSourceById(sourceId);
    if (!source) {
      return;
    }

    const providerFactory = this.providers[source.providerId];
    if (!providerFactory) {
      this.setStatus(`Storage source type for ${source.label} is unavailable.`, 'warn');
      return;
    }

    try {
      const provider = providerFactory();
      const result = await provider.connect(source.config || {});
      if (!result.ok) {
        const next = {
          ...source,
          status: result.message,
          needsReconnect: true,
          needsCredentials:
            source.providerId === 'github' ||
            (source.providerId === 'gdrive' && source.config?.sourceMode === 'auth-manifest-file'),
        };
        this.state.sources = this.state.sources.map((entry) => (entry.id === sourceId ? next : entry));
        this.renderSourcesList();
        this.saveSourcesToStorage();
        this.setConnectionStatus(result.message, false);
        this.setStatus(`Refresh failed: ${result.message}`, 'warn');
        return;
      }

      const loaded = await provider.listAssets();
      const refreshedConfig = { ...(source.config || {}) };
      if (source.providerId === 'gdrive') {
        refreshedConfig._manifestTitle = result.sourceDisplayLabel || source.displayLabel || '';
        refreshedConfig._normalizedFileId = result.fileId || source.config?.fileId || '';
        refreshedConfig._normalizedManifestUrl = result.normalizedManifestUrl || '';
      }
      const displayLabel =
        result.sourceDisplayLabel || this.sourceDisplayLabelFor(source.providerId, refreshedConfig, source.providerLabel);
      const detailLabel =
        result.sourceDetailLabel || this.sourceDetailLabelFor(source.providerId, refreshedConfig, source.providerLabel);
      const updatedSource = {
        ...source,
        provider,
        capabilities: provider.getCapabilities(),
        itemCount: loaded.length,
        status: result.message,
        authMode:
          source.providerId === 'gdrive' && source.config?.sourceMode === 'auth-manifest-file'
            ? 'google-auth'
            : source.authMode,
        displayLabel,
        detailLabel,
        label: detailLabel,
        config:
          source.providerId === 'gdrive'
            ? {
                ...(source.config || {}),
                fileId: result.fileId || source.config?.fileId || '',
                sourceMode: source.config?.sourceMode || 'public-manifest-url',
              }
            : source.config,
        collections: source.collections || [],
        selectedCollectionId: source.selectedCollectionId || null,
        needsReconnect: false,
        needsCredentials: false,
      };
      const normalized = this.normalizeSourceAssets(updatedSource, loaded);
      const collections = this.buildCollectionsForSource(updatedSource, normalized);
      const defaultCollectionId = collections[0]?.id || null;
      const normalizedWithCollections = normalized.map((item) => ({
        ...item,
        collectionId: item.collectionId || defaultCollectionId,
        collectionLabel: item.collectionLabel || collections.find((entry) => entry.id === (item.collectionId || defaultCollectionId))?.title || '',
      }));
      updatedSource.collections = collections;
      updatedSource.selectedCollectionId =
        (updatedSource.selectedCollectionId && collections.some((entry) => entry.id === updatedSource.selectedCollectionId))
          ? updatedSource.selectedCollectionId
          : defaultCollectionId;

      this.state.sources = this.state.sources.map((entry) => (entry.id === sourceId ? updatedSource : entry));
      this.mergeSourceAssets(sourceId, normalizedWithCollections);

      if (this.state.selectedItemId && !this.state.assets.some((item) => item.workspaceId === this.state.selectedItemId)) {
        this.state.selectedItemId = this.getVisibleAssets()[0]?.workspaceId || this.state.assets[0]?.workspaceId || null;
      }
      if (this.state.viewerItemId && !this.state.assets.some((item) => item.workspaceId === this.state.viewerItemId)) {
        this.closeViewer();
      } else if (this.state.viewerItemId) {
        this.renderViewer();
      }

      this.setConnectionStatus(`Refreshed storage source ${updatedSource.label}.`, true);
      this.setStatus(`Refreshed storage source ${updatedSource.label}.`, 'ok');
      this.renderSourcesList();
      this.renderSourceFilter();
      this.renderAssets();
      this.renderEditor();
      this.saveSourcesToStorage();
    } catch (error) {
      const next = {
        ...source,
        status: `Refresh error: ${error.message}`,
        needsReconnect: true,
        needsCredentials:
          source.providerId === 'github' ||
          (source.providerId === 'gdrive' && source.config?.sourceMode === 'auth-manifest-file'),
      };
      this.state.sources = this.state.sources.map((entry) => (entry.id === sourceId ? next : entry));
      this.renderSourcesList();
      this.saveSourcesToStorage();
      this.setConnectionStatus(`Refresh error: ${error.message}`, false);
      this.setStatus(`Refresh error: ${error.message}`, 'warn');
    }
  }

  removeSource(sourceId) {
    const source = this.getSourceById(sourceId);
    if (!source) {
      return;
    }

    this.state.sources = this.state.sources.filter((entry) => entry.id !== sourceId);
    this.state.assets = this.state.assets.filter((entry) => entry.sourceId !== sourceId);
    this.state.metadataMode = this.state.currentLevel === 'collections' ? 'collection' : 'item';
    if (this.state.sources.length === 0) {
      this.state.metadataMode = 'none';
      this.closeMobileEditor();
    }

    if (this.state.selectedItemId && !this.state.assets.some((item) => item.workspaceId === this.state.selectedItemId)) {
      this.state.selectedItemId = this.getVisibleAssets()[0]?.workspaceId || this.state.assets[0]?.workspaceId || null;
    }
    if (this.state.viewerItemId && !this.state.assets.some((item) => item.workspaceId === this.state.viewerItemId)) {
      this.closeViewer();
    }

    if (this.state.sources.length === 0) {
      this.setConnectionStatus('No hosts connected.', 'neutral');
      this.setStatus('No hosts connected.', 'neutral');
    } else {
      this.setStatus(`Removed storage source ${source.label}.`, 'ok');
    }

    this.state.manifest = null;
    this.dom.manifestPreview.textContent = '{}';
    this.renderSourcesList();
    this.renderSourceFilter();
    this.renderAssets();
    this.renderEditor();
    this.saveSourcesToStorage();
  }

  currentCollectionMeta() {
    const collectionId = this.dom.collectionId.value.trim() || COLLECTOR_CONFIG.defaultCollectionMeta.id;
    return {
      id: collectionId,
      title: this.dom.collectionTitle.value.trim() || COLLECTOR_CONFIG.defaultCollectionMeta.title,
      description:
        this.dom.collectionDescription.value.trim() || COLLECTOR_CONFIG.defaultCollectionMeta.description,
      license: this.dom.collectionLicense.value.trim(),
      publisher: this.dom.collectionPublisher.value.trim(),
      language: this.dom.collectionLanguage.value.trim(),
      rootPath: this.activeCollectionRootPath() || this.normalizeCollectionRootPath(`${collectionId}/`, collectionId),
    };
  }

  toManifestItem(item) {
    return ManifestService.toManifestItem(this, item);
  }

  buildManifestFromState() {
    return ManifestService.buildManifestFromState(this);
  }

  async generateManifest(options = {}) {
    return ManifestService.generateManifest(this, options);
  }

  resolvePublishSource() {
    if (!this.state.sources.length) {
      return null;
    }
    if (this.state.activeSourceFilter === 'all') {
      return null;
    }
    return this.getSourceById(this.state.activeSourceFilter);
  }

  async publishActiveSourceDraft() {
    const source = this.resolvePublishSource();
    if (!source) {
      this.setStatus('Select a single source in the viewport filter before publishing.', 'warn');
      return;
    }

    if (source.providerId !== 'github') {
      this.setStatus('Publish upload is currently implemented for GitHub sources only.', 'warn');
      return;
    }

    if (!source.provider || typeof source.provider.publishCollection !== 'function') {
      this.setStatus('This source does not support upload publishing yet.', 'warn');
      return;
    }
    if ((this.state.selectedCollectionId || 'all') === 'all') {
      this.setStatus('Select one collection before publishing.', 'warn');
      return;
    }

    const manifest = await this.generateManifest({ silent: true });
    if (!manifest) {
      return;
    }
    const collectionRootPath = this.activeCollectionRootPath() || this.normalizeCollectionRootPath(`${manifest.id}/`, manifest.id);

    const pending = this.state.assets.filter(
      (item) =>
        item.sourceId === source.id &&
        item.collectionId === this.state.selectedCollectionId &&
        item.isLocalDraftAsset &&
        item.include !== false &&
        item.draftUploadStatus !== 'uploaded',
    );

    if (pending.length === 0) {
      this.setStatus('No pending local assets. Uploading manifest only...', 'neutral');
    } else {
      this.setStatus(`Uploading ${pending.length} asset(s) to GitHub...`, 'neutral');
    }

    this.state.assets = this.state.assets.map((item) => {
      if (!pending.some((entry) => entry.workspaceId === item.workspaceId)) {
        return item;
      }
      return {
        ...item,
        draftUploadStatus: 'uploading',
        uploadError: '',
      };
    });
    this.renderAssets();
    this.renderEditor();

    const uploads = [];
    let failedPreparationCount = 0;
    for (const item of pending) {
      const original = await this.loadLocalAssetBlob(item, 'original');
      if (!original) {
        failedPreparationCount += 1;
        this.state.assets = this.state.assets.map((entry) =>
          entry.workspaceId === item.workspaceId
            ? { ...entry, draftUploadStatus: 'failed', uploadError: 'Original file missing from local draft storage.' }
            : entry,
        );
        continue;
      }

      uploads.push({
        path: this.joinCollectionRootPath(collectionRootPath, item.media?.url || ''),
        blob: original,
        message: `Upload ${item.id} original via Open Collections Manager`,
      });

      const thumb = await this.loadLocalAssetBlob(item, 'thumbnail');
      if (thumb && item.thumbnailRepoPath) {
        uploads.push({
          path: this.joinCollectionRootPath(collectionRootPath, item.thumbnailRepoPath),
          blob: thumb,
          message: `Upload ${item.id} thumbnail via Open Collections Manager`,
        });
      }
    }

    if (failedPreparationCount > 0) {
      this.renderAssets();
      this.renderEditor();
      this.setStatus(`${failedPreparationCount} asset(s) failed local draft preparation. Fix and retry publish.`, 'warn');
      return;
    }

    try {
      await source.provider.publishCollection({
        manifest,
        uploads,
        collectionRootPath,
        commitMessage: `Publish collection ${manifest.id} via Open Collections Manager`,
      });

      this.state.assets = this.state.assets.map((item) => {
        if (item.sourceId !== source.id || !item.isLocalDraftAsset) {
          return item;
        }
        const nextMediaRelativePath = item.media?.url || '';
        const nextThumbRelativePath = item.thumbnailRepoPath || item.media?.thumbnailUrl || '';
        return {
          ...item,
          media: {
            ...(item.media || {}),
            url: nextMediaRelativePath,
            thumbnailUrl: nextThumbRelativePath,
          },
          draftUploadStatus: 'uploaded',
          isLocalDraftAsset: false,
          uploadError: '',
        };
      });

      source.status = `Published ${manifest.id} to ${collectionRootPath}`;
      this.state.manifest = manifest;
      this.dom.manifestPreview.textContent = JSON.stringify(manifest, null, 2);
      this.refreshSourceCollectionsAndCounts(source.id);
      this.renderSourcesList();
      this.renderSourceFilter();
      this.renderCollectionFilter();
      this.state.currentLevel = 'collections';
      this.state.metadataMode = 'collection';
      this.state.openedCollectionId = null;
      this.closeMobileEditor();
      this.renderSourceContext();
      this.renderAssets();
      this.renderEditor();

      if (this.state.opfsAvailable) {
        await this.saveLocalDraft();
      }
      this.setStatus('Upload complete. GitHub media, thumbnails, and collection.json published.', 'ok');
    } catch (error) {
      this.state.assets = this.state.assets.map((item) => {
        if (item.sourceId !== source.id || item.draftUploadStatus !== 'uploading') {
          return item;
        }
        return {
          ...item,
          draftUploadStatus: 'failed',
          uploadError: error.message,
        };
      });
      this.renderAssets();
      this.renderEditor();
      this.setStatus(`Upload failed: ${error.message}`, 'warn');
    }
  }

  async copyManifestToClipboard() {
    return ManifestService.copyManifestToClipboard(this);
  }

  downloadManifest() {
    return ManifestService.downloadManifest(this);
  }
}

if (!customElements.get('open-collections-manager')) {
  customElements.define('open-collections-manager', OpenCollectionsManagerElement);
}

