﻿// Placeholder for future component extraction.
export function collectionBrowser() {}
