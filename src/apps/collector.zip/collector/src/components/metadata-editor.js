﻿// Placeholder for future component extraction.
export function metadataEditor() {}
