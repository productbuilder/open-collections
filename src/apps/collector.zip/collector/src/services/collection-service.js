﻿export function collectionIdExists(manager, collectionId) {
  if (!collectionId) {
    return false;
  }
  const id = collectionId.trim();
  if (!id) {
    return false;
  }
  for (const source of manager.state.sources) {
    if ((source.collections || []).some((entry) => entry.id === id)) {
      return true;
    }
  }
  if (manager.state.localDraftCollections.some((entry) => entry.id === id)) {
    return true;
  }
  return manager.state.assets.some((item) => item.collectionId === id);
}

export function ensureUniqueCollectionId(manager, baseId) {
  if (!collectionIdExists(manager, baseId)) {
    return baseId;
  }
  let index = 2;
  while (collectionIdExists(manager, `${baseId}-${index}`)) {
    index += 1;
  }
  return `${baseId}-${index}`;
}

export function buildInitialCollectionManifest(manager, meta) {
  const rootPath = manager.normalizeCollectionRootPath(meta.rootPath || `${meta.id}/`, meta.id);
  return {
    id: meta.id,
    title: meta.title,
    description: meta.description || '',
    license: meta.license || '',
    publisher: meta.publisher || '',
    language: meta.language || '',
    rootPath,
    items: [],
  };
}

export async function createNewCollectionDraft(manager) {
  const title = manager.dom.newCollectionTitle.value.trim();
  if (!title) {
    manager.setStatus('Enter a collection title to create a draft.', 'warn');
    return;
  }

  let slug = (manager.dom.newCollectionSlug.value || '').trim();
  if (!slug) {
    slug = manager.slugifySegment(title, 'new-collection');
  } else {
    slug = manager.slugifySegment(slug, 'new-collection');
  }

  slug = ensureUniqueCollectionId(manager, slug);
  const meta = {
    id: slug,
    title,
    description: manager.dom.newCollectionDescription.value.trim(),
    license: manager.dom.newCollectionLicense.value.trim(),
    publisher: manager.dom.newCollectionPublisher.value.trim(),
    language: manager.dom.newCollectionLanguage.value.trim(),
    rootPath: manager.normalizeCollectionRootPath(`${slug}/`, slug),
  };

  manager.setCollectionMetaFields(meta);
  manager.state.manifest = buildInitialCollectionManifest(manager, meta);
  manager.dom.manifestPreview.textContent = JSON.stringify(manager.state.manifest, null, 2);
  manager.state.selectedItemId = null;
  if (!manager.state.localDraftCollections.some((entry) => entry.id === slug)) {
    manager.state.localDraftCollections = [...manager.state.localDraftCollections, { id: slug, title, rootPath: meta.rootPath }];
  }

  if (manager.state.activeSourceFilter !== 'all') {
    const source = manager.getSourceById(manager.state.activeSourceFilter);
    if (source) {
      const exists = (source.collections || []).some((entry) => entry.id === slug);
      if (!exists) {
        source.collections = [
          ...(source.collections || []),
          { id: slug, title, rootPath: meta.rootPath },
        ];
      }
      source.selectedCollectionId = slug;
    }
  }

  manager.state.selectedCollectionId = slug;
  manager.state.metadataMode = 'collection';
  manager.closeDialog(manager.dom.newCollectionDialog);
  manager.renderSourcesList();
  manager.renderSourceFilter();
  manager.renderCollectionFilter();
  manager.renderAssets();
  manager.renderEditor();
  if (manager.isMobileViewport()) {
    manager.openMobileEditor();
  }

  if (manager.state.opfsAvailable) {
    await manager.saveLocalDraft();
  }
  manager.setStatus(`Created local draft collection ${slug}.`, 'ok');
}

export function openCollectionView(manager, collectionId) {
  if (!collectionId || collectionId === 'all') return;
  manager.state.selectedCollectionId = collectionId;
  manager.state.openedCollectionId = collectionId;
  manager.state.currentLevel = 'items';
  manager.state.metadataMode = 'item';
  manager.state.selectedItemId = null;
  manager.closeMobileEditor();
  manager.renderAssets();
  manager.renderEditor();
}

export function leaveCollectionView(manager) {
  manager.state.currentLevel = 'collections';
  manager.state.metadataMode = 'collection';
  manager.state.openedCollectionId = null;
  manager.state.selectedItemId = null;
  manager.closeMobileEditor();
  manager.renderAssets();
  manager.renderEditor();
}

export async function saveSelectedCollectionMetadata(manager) {
  const selected = manager.findSelectedCollectionMeta();
  if (!selected) {
    manager.setStatus('Select a collection to edit metadata.', 'warn');
    return;
  }
  const patch = {
    title: manager.dom.collectionEditorTitle.value.trim(),
    description: manager.dom.collectionEditorDescription.value.trim(),
    license: manager.dom.collectionEditorLicense.value.trim(),
    publisher: manager.dom.collectionEditorPublisher.value.trim(),
    language: manager.dom.collectionEditorLanguage.value.trim(),
  };
  if (manager.state.activeSourceFilter !== 'all') {
    const source = manager.getSourceById(manager.state.activeSourceFilter);
    if (source?.collections) {
      source.collections = source.collections.map((entry) => entry.id === selected.id ? { ...entry, ...patch } : entry);
    }
  }
  manager.state.localDraftCollections = manager.state.localDraftCollections.map((entry) => entry.id === selected.id ? { ...entry, ...patch } : entry);
  manager.renderAssets();
  manager.renderEditor();
  manager.setStatus(`Saved collection metadata for ${selected.id}.`, 'ok');
}
