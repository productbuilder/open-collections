
import '../../collector/src/components/pane-layout.js';
import './components/configurator-header.js';
import './components/configurator-section-browser.js';
import './components/configurator-inspector.js';
import { configuratorShellStyles } from './css/shell.css.js';
import {
  createSourceDescriptor,
  createWorkspaceState,
  sourceDescriptorLabel,
} from './workspace/source-model.js';

const WORKSPACES = new Set(['general', 'products', 'materials']);

const SECTION_LABELS = {
  info: 'Organization Info',
  supplierLinks: 'Supplier Links',
  availableCollections: 'Available Collections',
  defaults: 'Defaults / Policies',
  globalSettings: 'Global Settings',
  settings: 'Settings',
  packages: 'Packages',
  products: 'Products',
  configurations: 'Configurations',
  blocks: 'Blocks',
  connectorTypes: 'Connector Types',
  connectionTypes: 'Connection Types',
  blockCategoryTypes: 'Block Category Types',
  blockCategories: 'Block Categories',
  categories: 'Categories',
  meshes: 'Meshes',
  gltfs: 'GLTFs',
  loadingBases: 'Loading Bases',
  images: 'Images',
  materials: 'Materials',
  textures: 'Textures',
  materialSets: 'Material Sets',
  materialCategories: 'Material Categories',
  materialCategoryTypes: 'Material Category Types',
};

const PRODUCT_SECTION_ORDER = [
  'configurations',
  'blocks',
  'connectorTypes',
  'connectionTypes',
  'blockCategoryTypes',
  'blockCategories',
  'categories',
  'meshes',
  'gltfs',
  'loadingBases',
  'images',
  'settings',
  'defaults',
];

const MATERIAL_SECTION_ORDER = [
  'materials',
  'textures',
  'images',
  'materialSets',
  'materialCategories',
  'materialCategoryTypes',
  'settings',
  'defaults',
];

const GENERAL_SECTION_ORDER = ['info', 'supplierLinks', 'availableCollections', 'packages', 'products', 'globalSettings', 'settings', 'defaults'];

const DEFAULT_CARD_SECTIONS = new Set(['products-collections', 'materials-collections', 'products-entries:blocks']);

const RELATION_FIELD_TARGETS = {
  categoryId: 'categories',
  categoryIds: 'categories',
  blockCategoryTypeId: 'blockCategoryTypes',
  blockCategoryTypeIds: 'blockCategoryTypes',
  blockCategoryId: 'blockCategories',
  blockCategoryIds: 'blockCategories',
  meshId: 'meshes',
  meshIds: 'meshes',
  materialId: 'materials',
  materialIds: 'materials',
  textureId: 'textures',
  textureIds: 'textures',
  imageId: 'images',
  imageIds: 'images',
  gltfId: 'gltfs',
  gltfIds: 'gltfs',
  loadingBaseId: 'loadingBases',
  loadingBaseIds: 'loadingBases',
  connectorTypeId: 'connectorTypes',
  connectorTypeIds: 'connectorTypes',
  connectionTypeId: 'connectionTypes',
  connectionTypeIds: 'connectionTypes',
  blockId: 'blocks',
  blockIds: 'blocks',
  configurationId: 'configurations',
  configurationIds: 'configurations',
  materialSetId: 'materialSets',
  materialSetIds: 'materialSets',
};

function normalizeKey(value) {
  return String(value || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}

function slugify(value, fallback = 'item') {
  const slug = String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 64);
  return slug || fallback;
}

function cloneJson(value) {
  if (typeof structuredClone === 'function') {
    return structuredClone(value);
  }
  return JSON.parse(JSON.stringify(value));
}

function isPlainObject(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

function isEditableSection(value) {
  return Array.isArray(value) || isPlainObject(value);
}

function friendlySectionLabel(key) {
  if (SECTION_LABELS[key]) {
    return SECTION_LABELS[key];
  }
  return String(key || '')
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

function createEmptyValidation() {
  return {
    overviewWarnings: [],
    sections: {},
  };
}

function createManufacturerTemplate() {
  return {
    id: '',
    title: '',
    description: '',
    version: '1.0.0',
    info: {},
    supplierLinks: [],
    availableCollections: {
      products: [],
      materials: [],
    },
    defaults: {},
    globalSettings: {},
    settings: {},
  };
}

function createCollectionTemplate(workspace) {
  if (workspace === 'products') {
    return {
      id: '',
      title: '',
      description: '',
      version: '1.0.0',
      configurations: [],
      blocks: [],
      connectorTypes: [],
      connectionTypes: [],
      blockCategoryTypes: [],
      blockCategories: [],
      categories: [],
      meshes: [],
      gltfs: [],
      loadingBases: [],
      images: [],
      settings: {},
    };
  }

  return {
    id: '',
    title: '',
    description: '',
    version: '1.0.0',
    materials: [],
    textures: [],
    images: [],
    materialSets: [],
    materialCategories: [],
    materialCategoryTypes: [],
    settings: {},
    defaults: {},
  };
}
function validateArraySections(data) {
  const sections = {};
  if (!isPlainObject(data)) {
    return sections;
  }

  for (const [sectionId, sectionValue] of Object.entries(data)) {
    if (!Array.isArray(sectionValue)) {
      continue;
    }

    const missingIds = [];
    const duplicateIds = [];
    const entryWarnings = {};
    const seen = new Map();

    sectionValue.forEach((entry, index) => {
      const warnings = [];
      if (!isPlainObject(entry)) {
        warnings.push('Entry should be an object.');
      }
      const id = isPlainObject(entry) ? String(entry.id || '').trim() : '';
      if (!id) {
        missingIds.push(index);
        warnings.push('Missing id.');
      } else if (seen.has(id)) {
        duplicateIds.push(id);
        warnings.push(`Duplicate id: ${id}`);
        const first = seen.get(id);
        entryWarnings[first] = [...(entryWarnings[first] || []), `Duplicate id: ${id}`];
      } else {
        seen.set(id, index);
      }

      if (warnings.length > 0) {
        entryWarnings[index] = [...(entryWarnings[index] || []), ...warnings];
      }
    });

    const uniqueDuplicates = Array.from(new Set(duplicateIds));
    sections[sectionId] = {
      missingIds,
      duplicateIds: uniqueDuplicates,
      entryWarnings,
      warningCount: missingIds.length + uniqueDuplicates.length,
    };
  }

  return sections;
}

function validateDataRoot(workspace, data) {
  const result = createEmptyValidation();
  if (!isPlainObject(data)) {
    result.overviewWarnings.push(`${workspace} source root must be an object.`);
    return result;
  }

  if (workspace === 'products') {
    if (!Array.isArray(data.blocks)) {
      result.overviewWarnings.push('Missing blocks array.');
    }
    if (!Array.isArray(data.configurations)) {
      result.overviewWarnings.push('Missing configurations array.');
    }
  }

  if (workspace === 'materials') {
    if (!Array.isArray(data.materials)) {
      result.overviewWarnings.push('Missing materials array.');
    }
    if (!Array.isArray(data.textures)) {
      result.overviewWarnings.push('Missing textures array.');
    }
  }

  if (workspace === 'general') {
    if (!isPlainObject(data.info) && !isPlainObject(data.settings)) {
      result.overviewWarnings.push('Organization info/settings are missing.');
    }
  }

  result.sections = validateArraySections(data);
  return result;
}

function makeCollectionRecord(workspace, data, organizationId, fileHandle = null, fileName = '') {
  const derivedId = String(data?.id || '').trim() || slugify(fileName.replace(/\.[^.]+$/, ''), `${workspace}-collection`);
  const title = String(data?.title || data?.name || derivedId || `${workspace} collection`).trim() || `${workspace} collection`;
  const normalizedId = slugify(derivedId || title, `${workspace}-collection`);
  const ownerOrgId = String(data?.ownerOrganizationId || data?.sourceOrganizationId || organizationId || '').trim() || organizationId;
  const isLinkedExternal = ownerOrgId !== organizationId;

  const role = workspace === 'products' ? 'products' : 'materials';
  const source = createSourceDescriptor({
    role,
    label: title,
    ownerOrgId,
    collectionId: normalizedId,
    connectionType: 'local-file',
    fileHandle,
    fileName,
    sourcePath: fileName,
    isLinkedExternal,
    isLoaded: true,
    isDirty: false,
    data: isPlainObject(data) ? data : {},
    validation: validateDataRoot(workspace, data),
  });

  return {
    ...source,
    id: normalizedId,
    title,
    ownerOrganizationId: ownerOrgId,
    sourceOrganizationId: ownerOrgId,
    sourceType: source.connectionType,
    linked: source.isLinkedExternal,
  };
}

function setSourceDirty(source, dirty) {
  if (!source || typeof source !== 'object') {
    return;
  }
  source.isDirty = Boolean(dirty);
  source.dirty = Boolean(dirty);
}

function ensureUniqueEntryId(list, candidate) {
  const base = slugify(candidate, 'entry');
  const existing = new Set(
    (Array.isArray(list) ? list : [])
      .map((entry) => (isPlainObject(entry) ? String(entry.id || '').trim() : ''))
      .filter(Boolean),
  );
  if (!existing.has(base)) {
    return base;
  }
  let index = 2;
  while (existing.has(`${base}-${index}`)) {
    index += 1;
  }
  return `${base}-${index}`;
}

function mergeAdditive(base, addon) {
  if (!isPlainObject(addon)) {
    return base;
  }
  const target = isPlainObject(base) ? base : {};
  for (const [key, value] of Object.entries(addon)) {
    if (!(key in target)) {
      target[key] = cloneJson(value);
      continue;
    }
    if (isPlainObject(target[key]) && isPlainObject(value)) {
      target[key] = mergeAdditive(target[key], value);
      continue;
    }
    if (Array.isArray(target[key]) && Array.isArray(value) && target[key].length === 0 && value.length > 0) {
      target[key] = cloneJson(value);
    }
  }
  return target;
}

function buildIdSets(data) {
  const map = new Map();
  if (!isPlainObject(data)) {
    return map;
  }
  for (const [sectionId, sectionValue] of Object.entries(data)) {
    if (!Array.isArray(sectionValue)) {
      continue;
    }
    const ids = new Set();
    for (const entry of sectionValue) {
      if (!isPlainObject(entry)) {
        continue;
      }
      const id = String(entry.id || '').trim();
      if (id) {
        ids.add(id);
      }
    }
    map.set(sectionId, ids);
  }
  return map;
}

function buildRelationOptionsFromData(data) {
  const options = {};
  if (!isPlainObject(data)) {
    return options;
  }
  for (const [key, value] of Object.entries(data)) {
    if (!Array.isArray(value)) {
      continue;
    }
    options[key] = value
      .map((entry) => {
        if (!isPlainObject(entry)) {
          return null;
        }
        const id = String(entry.id || '').trim();
        if (!id) {
          return null;
        }
        const title = String(entry.title || entry.name || entry.label || '').trim();
        return {
          value: id,
          label: title ? `${id} - ${title}` : id,
        };
      })
      .filter(Boolean);
  }
  return options;
}

function mergeRelationOptions(target, source) {
  const merged = { ...target };
  for (const [key, value] of Object.entries(source || {})) {
    const existing = Array.isArray(merged[key]) ? merged[key] : [];
    const byId = new Map(existing.map((item) => [String(item.value), item]));
    for (const item of Array.isArray(value) ? value : []) {
      byId.set(String(item.value), item);
    }
    merged[key] = Array.from(byId.values()).sort((a, b) => String(a.label).localeCompare(String(b.label)));
  }
  return merged;
}
class OpenConfiguratorManagerElement extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    const defaultOrganizationId = 'org-4x6-sofa';
    this.state = {
      organizations: [
        {
          id: defaultOrganizationId,
          label: '4x6 sofa',
        },
      ],
      workspace: createWorkspaceState(defaultOrganizationId),
      activeWorkspace: 'general',
      currentLevel: 'general-sections',
      activeSectionId: null,
      selectedEntryRef: null,
      viewModes: {},
      relationOptions: {},
      statusText: 'Select an organization and open source files to begin.',
      pendingOpenTarget: null,
    };
  }

  connectedCallback() {
    this.render();
    this.cacheDom();
    this.bindEvents();
    this.recomputeDerivedState();
    this.refreshAll();
  }

  render() {
    this.shadowRoot.innerHTML = `
      <style>${configuratorShellStyles}</style>
      <div class="app-shell">
        <open-configurator-header id="configHeader"></open-configurator-header>
        <section class="workspace">
          <open-pane-layout id="paneLayout" inspector-placement="hidden">
            <open-configurator-section-browser id="sectionBrowser" slot="main"></open-configurator-section-browser>
            <open-configurator-inspector id="inspector" slot="inspector"></open-configurator-inspector>
          </open-pane-layout>
        </section>
        <input id="openFileInput" type="file" accept=".json,application/json" hidden />
      </div>
    `;
  }

  cacheDom() {
    const root = this.shadowRoot;
    this.dom = {
      header: root.getElementById('configHeader'),
      paneLayout: root.getElementById('paneLayout'),
      sectionBrowser: root.getElementById('sectionBrowser'),
      inspector: root.getElementById('inspector'),
      openFileInput: root.getElementById('openFileInput'),
    };
  }

  bindEvents() {
    this.dom.header.addEventListener('workspace-select', (event) => {
      this.switchWorkspace(event.detail?.workspace || 'general');
    });

    this.dom.header.addEventListener('organization-select', (event) => {
      const organizationId = event.detail?.organizationId || '';
      if (organizationId) {
        this.state.workspace.currentOrganizationId = organizationId;
        this.state.statusText = `Organization switched to ${this.currentOrganizationLabel()}.`;
        this.refreshAll();
      }
    });

    this.dom.sectionBrowser.addEventListener('panel-back', () => {
      this.navigateBack();
    });

    this.dom.sectionBrowser.addEventListener('panel-action', (event) => {
      const actionId = event.detail?.actionId || '';
      if (actionId) {
        this.handlePanelAction(actionId);
      }
    });

    this.dom.sectionBrowser.addEventListener('entry-select', (event) => {
      const nextEntryRef = event.detail?.entryRef || null;
      this.state.selectedEntryRef = nextEntryRef;
      this.normalizeSelection();
      this.renderBrowser();
      this.renderInspector();
    });

    this.dom.sectionBrowser.addEventListener('section-open', (event) => {
      const index = Number(event.detail?.index);
      if (!Number.isInteger(index)) {
        return;
      }
      this.state.selectedEntryRef = { index };
      if (this.state.currentLevel === 'products-collections' || this.state.currentLevel === 'materials-collections') {
        this.openCollectionAtIndex(index);
        return;
      }
      if (
        this.state.currentLevel === 'general-sections'
        || this.state.currentLevel === 'products-sections'
        || this.state.currentLevel === 'materials-sections'
      ) {
        this.openSectionAtIndex(index);
      }
    });

    this.dom.sectionBrowser.addEventListener('view-mode-change', (event) => {
      const mode = event.detail?.mode === 'cards' ? 'cards' : 'rows';
      const key = this.currentViewModeKey();
      this.state.viewModes = {
        ...this.state.viewModes,
        [key]: mode,
      };
      this.renderBrowser();
    });

    this.dom.sectionBrowser.addEventListener('array-action', (event) => {
      const action = event.detail?.action || '';
      if (action) {
        this.applyArrayAction(action);
      }
    });

    this.dom.inspector.addEventListener('entry-change', (event) => {
      this.applyEntryChange(event.detail || {});
    });

    this.dom.openFileInput.addEventListener('change', async (event) => {
      const file = event.target?.files?.[0] || null;
      if (file) {
        await this.handlePendingOpenFile(file);
      }
      event.target.value = '';
    });
  }
  currentOrganizationLabel() {
    const currentOrganizationId = this.currentOrganizationId();
    return this.state.organizations.find((org) => org.id === currentOrganizationId)?.label || 'Organization';
  }

  setStatus(text) {
    const next = String(text || '').trim();
    if (next) {
      this.state.statusText = next;
      this.renderHeader();
    }
  }

  currentOrganizationId() {
    return this.state.workspace.currentOrganizationId;
  }

  manufacturerSource() {
    return this.state.workspace.sources.manufacturer;
  }

  productSource() {
    return this.state.workspace.sources.products;
  }

  productSources() {
    const source = this.productSource();
    return source ? [source] : [];
  }

  materialSources() {
    return Array.isArray(this.state.workspace.sources.materials)
      ? this.state.workspace.sources.materials
      : [];
  }

  selectedProductSource() {
    const source = this.productSource();
    if (!source) {
      return null;
    }
    const activeId = this.state.workspace.activeProductSourceId;
    if (!activeId || activeId === source.sourceId || activeId === source.id) {
      return source;
    }
    return source;
  }

  selectedMaterialSource() {
    const sources = this.materialSources();
    const activeId = this.state.workspace.activeMaterialSourceId;
    if (!activeId) {
      return sources[0] || null;
    }
    return sources.find((entry) => entry.sourceId === activeId || entry.id === activeId) || sources[0] || null;
  }

  workspaceGeneratedPackage() {
    return this.state.workspace.generatedPackageData;
  }

  workspaceExportWarnings() {
    return Array.isArray(this.state.workspace.exportWarnings)
      ? this.state.workspace.exportWarnings
      : [];
  }

  currentWorkspaceCollections() {
    if (this.state.activeWorkspace === 'products') {
      return this.productSources();
    }
    if (this.state.activeWorkspace === 'materials') {
      return this.materialSources();
    }
    return [];
  }

  selectedCollection() {
    if (this.state.activeWorkspace === 'products') {
      return this.selectedProductSource();
    }
    if (this.state.activeWorkspace === 'materials') {
      return this.selectedMaterialSource();
    }
    return null;
  }

  currentWorkspaceOrder() {
    if (this.state.activeWorkspace === 'products') {
      return PRODUCT_SECTION_ORDER;
    }
    if (this.state.activeWorkspace === 'materials') {
      return MATERIAL_SECTION_ORDER;
    }
    return GENERAL_SECTION_ORDER;
  }

  sectionListForData(data, validation = createEmptyValidation()) {
    if (!isPlainObject(data)) {
      return [];
    }

    const order = this.currentWorkspaceOrder();
    const orderMap = new Map(order.map((key, index) => [normalizeKey(key), index]));
    const keys = Object.keys(data).filter((key) => isEditableSection(data[key]));
    keys.sort((a, b) => {
      const ai = orderMap.has(normalizeKey(a)) ? orderMap.get(normalizeKey(a)) : Number.MAX_SAFE_INTEGER;
      const bi = orderMap.has(normalizeKey(b)) ? orderMap.get(normalizeKey(b)) : Number.MAX_SAFE_INTEGER;
      if (ai !== bi) {
        return ai - bi;
      }
      return a.localeCompare(b);
    });

    const sections = keys.map((key) => {
      const value = data[key];
      return {
        id: key,
        title: friendlySectionLabel(key),
        type: Array.isArray(value) ? 'array' : 'object',
        count: Array.isArray(value) ? value.length : Object.keys(value || {}).length,
        warningCount: validation.sections?.[key]?.warningCount || 0,
      };
    });

    if (this.state.activeWorkspace === 'products') {
      sections.push({
        id: '__export__',
        title: 'Export / Package',
        type: 'export',
        count: null,
        warningCount: this.workspaceExportWarnings().length,
      });
    }

    return sections;
  }

  currentEntryContext() {
    if (this.state.currentLevel === 'general-entries') {
      return {
        ownerType: 'manufacturer',
        owner: this.manufacturerSource(),
        sectionId: this.state.activeSectionId,
        workspace: 'general',
      };
    }

    if (this.state.currentLevel === 'products-entries') {
      const collection = this.selectedCollection();
      return {
        ownerType: 'collection',
        owner: collection,
        sectionId: this.state.activeSectionId,
        workspace: 'products',
      };
    }

    if (this.state.currentLevel === 'materials-entries') {
      const collection = this.selectedCollection();
      return {
        ownerType: 'collection',
        owner: collection,
        sectionId: this.state.activeSectionId,
        workspace: 'materials',
      };
    }

    return null;
  }

  currentSectionValue() {
    const context = this.currentEntryContext();
    if (!context || !context.owner || !isPlainObject(context.owner.data)) {
      return null;
    }
    return context.owner.data[context.sectionId];
  }

  currentSectionValidation() {
    const context = this.currentEntryContext();
    if (!context || !context.owner) {
      return null;
    }
    return context.owner.validation?.sections?.[context.sectionId] || null;
  }

  currentViewModeKey() {
    if (this.state.currentLevel === 'products-collections') {
      return 'products-collections';
    }
    if (this.state.currentLevel === 'materials-collections') {
      return 'materials-collections';
    }
    if (this.state.currentLevel === 'products-entries') {
      return `products-entries:${this.state.activeSectionId || 'section'}`;
    }
    if (this.state.currentLevel === 'materials-entries') {
      return `materials-entries:${this.state.activeSectionId || 'section'}`;
    }
    return `${this.state.currentLevel}`;
  }

  currentViewMode() {
    const key = this.currentViewModeKey();
    const fromState = this.state.viewModes[key];
    if (fromState === 'cards' || fromState === 'rows') {
      return fromState;
    }
    return DEFAULT_CARD_SECTIONS.has(key) ? 'cards' : 'rows';
  }

  inspectorVisible() {
    return this.state.currentLevel === 'general-entries'
      || this.state.currentLevel === 'products-entries'
      || this.state.currentLevel === 'materials-entries';
  }

  switchWorkspace(workspace) {
    if (!WORKSPACES.has(workspace)) {
      return;
    }

    this.state.activeWorkspace = workspace;
    this.state.activeSectionId = null;
    this.state.selectedEntryRef = null;

    if (workspace === 'general') {
      this.state.currentLevel = 'general-sections';
    }
    if (workspace === 'products') {
      this.state.currentLevel = 'products-collections';
    }
    if (workspace === 'materials') {
      this.state.currentLevel = 'materials-collections';
    }

    this.refreshAll();
  }

  navigateBack() {
    if (this.state.currentLevel === 'general-entries') {
      this.state.currentLevel = 'general-sections';
      this.state.activeSectionId = null;
      this.state.selectedEntryRef = null;
    } else if (this.state.currentLevel === 'products-sections') {
      this.state.currentLevel = 'products-collections';
      this.state.selectedEntryRef = null;
    } else if (this.state.currentLevel === 'products-entries' || this.state.currentLevel === 'products-export') {
      this.state.currentLevel = 'products-sections';
      this.state.activeSectionId = null;
      this.state.selectedEntryRef = null;
    } else if (this.state.currentLevel === 'materials-sections') {
      this.state.currentLevel = 'materials-collections';
      this.state.selectedEntryRef = null;
    } else if (this.state.currentLevel === 'materials-entries') {
      this.state.currentLevel = 'materials-sections';
      this.state.activeSectionId = null;
      this.state.selectedEntryRef = null;
    }

    this.refreshAll();
  }
  recomputeDerivedState() {
    const manufacturer = this.manufacturerSource();
    if (manufacturer) {
      manufacturer.validation = validateDataRoot('general', manufacturer.data);
      manufacturer.isLoaded = isPlainObject(manufacturer.data);
      manufacturer.dirty = Boolean(manufacturer.isDirty);
    }

    const products = this.productSource();
    if (products) {
      products.validation = validateDataRoot('products', products.data);
      products.isLoaded = isPlainObject(products.data);
      products.dirty = Boolean(products.isDirty);
    }

    this.state.workspace.sources.materials = this.materialSources().map((source) => {
      const next = {
        ...source,
        validation: validateDataRoot('materials', source.data),
        isLoaded: isPlainObject(source.data),
      };
      next.dirty = Boolean(next.isDirty);
      return next;
    });

    this.rebuildRelationOptions();
    this.refreshExportSnapshot();
    this.normalizeSelection();
  }

  rebuildRelationOptions() {
    let options = {};
    options = mergeRelationOptions(options, buildRelationOptionsFromData(this.manufacturerSource()?.data));

    for (const source of this.productSources()) {
      options = mergeRelationOptions(options, buildRelationOptionsFromData(source.data));
    }
    for (const source of this.materialSources()) {
      options = mergeRelationOptions(options, buildRelationOptionsFromData(source.data));
    }

    this.state.relationOptions = options;
  }

  refreshExportSnapshot() {
    const selectedProduct = this.selectedProductSource();
    const warnings = [];
    if (!selectedProduct) {
      warnings.push('No connected products source.');
      this.state.workspace.generatedPackageData = {};
      this.state.workspace.exportWarnings = warnings;
      return;
    }

    const base = cloneJson(selectedProduct.data || {});
    const manufacturer = this.manufacturerSource();
    const withOrg = isPlainObject(manufacturer?.data) ? mergeAdditive(base, manufacturer.data) : base;
    let merged = withOrg;

    const materialSources = this.materialSources();
    if (materialSources.length === 0) {
      warnings.push('No material collections loaded.');
    }

    for (const source of materialSources) {
      merged = mergeAdditive(merged, source.data || {});
    }

    const arrayValidation = validateArraySections(merged);
    for (const [sectionId, sectionValidation] of Object.entries(arrayValidation)) {
      if (sectionValidation.missingIds.length > 0) {
        warnings.push(`${friendlySectionLabel(sectionId)} has entries missing id.`);
      }
      if (sectionValidation.duplicateIds.length > 0) {
        warnings.push(`${friendlySectionLabel(sectionId)} has duplicate ids: ${sectionValidation.duplicateIds.join(', ')}`);
      }
    }

    const idSets = buildIdSets(merged);
    const relationWarnings = [];
    for (const [sectionId, sectionValue] of Object.entries(merged)) {
      if (!Array.isArray(sectionValue)) {
        continue;
      }
      sectionValue.forEach((entry, index) => {
        if (!isPlainObject(entry)) {
          return;
        }
        for (const [fieldName, targetSection] of Object.entries(RELATION_FIELD_TARGETS)) {
          if (!(fieldName in entry)) {
            continue;
          }
          const targetIds = idSets.get(targetSection);
          if (!targetIds || targetIds.size === 0) {
            continue;
          }
          const value = entry[fieldName];
          if (Array.isArray(value)) {
            for (const item of value) {
              const id = String(item || '').trim();
              if (id && !targetIds.has(id)) {
                relationWarnings.push(`${sectionId}[${index}] ${fieldName} -> missing ${targetSection}:${id}`);
              }
            }
          } else {
            const id = String(value || '').trim();
            if (id && !targetIds.has(id)) {
              relationWarnings.push(`${sectionId}[${index}] ${fieldName} -> missing ${targetSection}:${id}`);
            }
          }
        }
      });
    }

    this.state.workspace.generatedPackageData = merged;
    this.state.workspace.exportWarnings = [...warnings, ...Array.from(new Set(relationWarnings)).slice(0, 120)];
  }

  normalizeSelection() {
    if (this.state.currentLevel.startsWith('products-')) {
      const products = this.productSources();
      const activeProductSourceId = this.state.workspace.activeProductSourceId;
      const exists = products.some((entry) => entry.sourceId === activeProductSourceId || entry.id === activeProductSourceId);
      if (!exists) {
        this.state.workspace.activeProductSourceId = products[0]?.sourceId || products[0]?.id || null;
      }
      if (!this.state.workspace.activeProductSourceId && this.state.currentLevel !== 'products-collections') {
        this.state.currentLevel = 'products-collections';
      }
    }

    if (this.state.currentLevel.startsWith('materials-')) {
      const materials = this.materialSources();
      const activeMaterialSourceId = this.state.workspace.activeMaterialSourceId;
      const exists = materials.some((entry) => entry.sourceId === activeMaterialSourceId || entry.id === activeMaterialSourceId);
      if (!exists) {
        this.state.workspace.activeMaterialSourceId = materials[0]?.sourceId || materials[0]?.id || null;
      }
      if (!this.state.workspace.activeMaterialSourceId && this.state.currentLevel !== 'materials-collections') {
        this.state.currentLevel = 'materials-collections';
      }
    }

    const list = this.currentListEntries();

    if (this.state.currentLevel.endsWith('sections') || this.state.currentLevel.endsWith('collections')) {
      if (list.length === 0) {
        this.state.selectedEntryRef = null;
        return;
      }
      const index = Number(this.state.selectedEntryRef?.index);
      if (!Number.isInteger(index) || index < 0 || index >= list.length) {
        this.state.selectedEntryRef = { index: 0 };
      }
      const resolvedIndex = Number(this.state.selectedEntryRef?.index);
      if (this.state.currentLevel === 'products-collections' && Number.isInteger(resolvedIndex) && list[resolvedIndex]) {
        this.state.workspace.activeProductSourceId = list[resolvedIndex].sourceId || list[resolvedIndex].id;
      }
      if (this.state.currentLevel === 'materials-collections' && Number.isInteger(resolvedIndex) && list[resolvedIndex]) {
        this.state.workspace.activeMaterialSourceId = list[resolvedIndex].sourceId || list[resolvedIndex].id;
      }
      return;
    }

    const context = this.currentEntryContext();
    if (!context) {
      this.state.selectedEntryRef = null;
      return;
    }

    const value = this.currentSectionValue();
    if (Array.isArray(value)) {
      if (value.length === 0) {
        this.state.selectedEntryRef = null;
        return;
      }
      const index = Number(this.state.selectedEntryRef?.index);
      if (!Number.isInteger(index) || index < 0 || index >= value.length) {
        this.state.selectedEntryRef = { index: 0 };
      }
      return;
    }

    if (isPlainObject(value)) {
      const keys = Object.keys(value);
      if (keys.length === 0) {
        this.state.selectedEntryRef = { scope: 'section' };
        return;
      }
      const key = this.state.selectedEntryRef?.key;
      if (!key || !keys.includes(key)) {
        this.state.selectedEntryRef = { key: keys[0] };
      }
      return;
    }

    this.state.selectedEntryRef = null;
  }

  currentListEntries() {
    if (this.state.currentLevel === 'products-collections') {
      return this.productSources();
    }
    if (this.state.currentLevel === 'materials-collections') {
      return this.materialSources();
    }
    if (this.state.currentLevel === 'products-sections' || this.state.currentLevel === 'materials-sections' || this.state.currentLevel === 'general-sections') {
      return this.sectionEntriesForCurrentLevel();
    }
    return [];
  }

  sectionEntriesForCurrentLevel() {
    if (this.state.currentLevel === 'general-sections') {
      const manufacturer = this.manufacturerSource();
      return this.sectionListForData(manufacturer?.data, manufacturer?.validation);
    }

    const collection = this.selectedCollection();
    if (!collection) {
      return [];
    }
    return this.sectionListForData(collection.data, collection.validation);
  }

  contextActions() {
    if (this.state.currentLevel === 'general-sections') {
      return [
        { id: 'new-manufacturer', label: 'New' },
        { id: 'open-manufacturer', label: 'Open' },
        { id: 'save-manufacturer', label: 'Save', variant: 'primary', disabled: !this.manufacturerSource()?.data },
      ];
    }

    if (this.state.currentLevel === 'general-entries') {
      return [
        { id: 'save-manufacturer', label: 'Save', variant: 'primary', disabled: !this.manufacturerSource()?.data },
      ];
    }

    if (this.state.currentLevel === 'products-collections') {
      return [
        { id: 'new-product-collection', label: 'New' },
        { id: 'open-product-collection-file', label: 'Open' },
        { id: 'save-product-collection', label: 'Save', variant: 'primary', disabled: !this.selectedCollection() },
      ];
    }

    if (this.state.currentLevel === 'products-sections') {
      return [
        { id: 'new-product-collection', label: 'New' },
        { id: 'open-product-collection-file', label: 'Open' },
        { id: 'save-product-collection', label: 'Save', variant: 'primary', disabled: !this.selectedCollection() },
      ];
    }

    if (this.state.currentLevel === 'products-entries') {
      return [
        { id: 'save-product-collection', label: 'Save', variant: 'primary', disabled: !this.selectedCollection() },
      ];
    }

    if (this.state.currentLevel === 'products-export') {
      return [
        { id: 'generate-export', label: 'Generate Export', variant: 'primary' },
        { id: 'download-export', label: 'Download Export', disabled: !isPlainObject(this.workspaceGeneratedPackage()) || Object.keys(this.workspaceGeneratedPackage()).length === 0 },
      ];
    }

    if (this.state.currentLevel === 'materials-collections') {
      return [
        { id: 'new-material-collection', label: 'New' },
        { id: 'open-material-collection-file', label: 'Open' },
        { id: 'save-material-collection', label: 'Save', variant: 'primary', disabled: !this.selectedCollection() },
      ];
    }

    if (this.state.currentLevel === 'materials-sections') {
      return [
        { id: 'new-material-collection', label: 'New' },
        { id: 'open-material-collection-file', label: 'Open' },
        { id: 'save-material-collection', label: 'Save', variant: 'primary', disabled: !this.selectedCollection() },
      ];
    }

    if (this.state.currentLevel === 'materials-entries') {
      return [
        { id: 'save-material-collection', label: 'Save', variant: 'primary', disabled: !this.selectedCollection() },
      ];
    }

    return [];
  }

  sourceMetaText(source) {
    if (!source) {
      return 'No source connected';
    }
    const parts = [];
    parts.push(sourceDescriptorLabel(source));
    if (source.isDirty) {
      parts.push('Unsaved');
    }
    return parts.join(' | ');
  }

  browserModel() {
    const model = {
      section: { id: 'overview', label: 'Workspace', kind: 'overview' },
      sectionValue: null,
      selectedEntryRef: this.state.selectedEntryRef,
      arrayPresentation: 'data',
      showBack: this.state.currentLevel !== 'general-sections' && this.state.currentLevel !== 'products-collections' && this.state.currentLevel !== 'materials-collections',
      showViewToggle: true,
      contextActions: this.contextActions(),
      overviewStats: [],
      overviewWarnings: [],
      exportPayload: null,
      viewMode: this.currentViewMode(),
      sectionValidation: null,
      arrayActions: this.arrayActionState(),
      sourceMeta: '',
    };

    if (this.state.currentLevel === 'general-sections') {
      const manufacturer = this.manufacturerSource();
      model.section = { id: 'general-sections', label: 'General Sections', kind: 'array' };
      model.sectionValue = this.sectionEntriesForCurrentLevel();
      model.showViewToggle = false;
      model.arrayPresentation = 'section-nav';
      model.overviewWarnings = manufacturer?.validation?.overviewWarnings || [];
      model.sourceMeta = this.sourceMetaText(manufacturer);
      return model;
    }

    if (this.state.currentLevel === 'products-collections') {
      model.section = { id: 'products-collections', label: 'Product Collections', kind: 'array' };
      const sources = this.productSources();
      model.sectionValue = sources.map((source) => ({
        sourceId: source.sourceId,
        id: source.id,
        title: source.title,
        type: source.connectionType || source.sourceType || 'source',
        count: Object.keys(source.data || {}).filter((key) => isEditableSection(source.data?.[key])).length,
        warningCount: Number(source.validation?.overviewWarnings?.length || 0),
        metaText: [
          source.fileName || '',
          source.isLinkedExternal ? 'linked' : 'local',
          source.isDirty ? 'unsaved' : '',
        ].filter(Boolean).join(' | '),
        owner: source.ownerOrganizationId || source.ownerOrgId,
        sourceType: source.sourceType || source.connectionType,
        sourceLabel: source.label,
        fileName: source.fileName,
        connectionType: source.connectionType,
        isLinkedExternal: source.isLinkedExternal,
        isDirty: Boolean(source.isDirty),
      }));
      model.showViewToggle = false;
      model.arrayPresentation = 'section-nav';
      if (sources[0]) {
        model.sourceMeta = this.sourceMetaText(sources[0]);
      }
      return model;
    }

    if (this.state.currentLevel === 'materials-collections') {
      model.section = { id: 'materials-collections', label: 'Material Collections', kind: 'array' };
      const sources = this.materialSources();
      model.sectionValue = sources.map((source) => ({
        sourceId: source.sourceId,
        id: source.id,
        title: source.title,
        type: source.connectionType || source.sourceType || 'source',
        count: Object.keys(source.data || {}).filter((key) => isEditableSection(source.data?.[key])).length,
        warningCount: Number(source.validation?.overviewWarnings?.length || 0),
        metaText: [
          source.fileName || '',
          source.isLinkedExternal ? 'linked' : 'local',
          source.isDirty ? 'unsaved' : '',
        ].filter(Boolean).join(' | '),
        owner: source.ownerOrganizationId || source.ownerOrgId,
        sourceType: source.sourceType || source.connectionType,
        sourceLabel: source.label,
        fileName: source.fileName,
        connectionType: source.connectionType,
        isLinkedExternal: source.isLinkedExternal,
        isDirty: Boolean(source.isDirty),
      }));
      model.showViewToggle = false;
      model.arrayPresentation = 'section-nav';
      if (sources.length > 0) {
        model.sourceMeta = `${sources.length} connected material source${sources.length === 1 ? '' : 's'}`;
      }
      return model;
    }

    if (this.state.currentLevel === 'products-sections' || this.state.currentLevel === 'materials-sections') {
      const collection = this.selectedCollection();
      const label = this.state.currentLevel === 'products-sections' ? 'Product Sections' : 'Material Sections';
      model.section = { id: 'collection-sections', label: collection?.title ? `${collection.title} ${label}` : label, kind: 'array' };
      model.sectionValue = this.sectionEntriesForCurrentLevel();
      model.showViewToggle = false;
      model.arrayPresentation = 'section-nav';
      model.sourceMeta = this.sourceMetaText(collection);
      return model;
    }

    if (this.state.currentLevel === 'products-export') {
      model.section = { id: 'export', label: 'Export / Package', kind: 'export' };
      model.showViewToggle = false;
      model.exportPayload = {
        warnings: this.workspaceExportWarnings(),
        summary: this.exportSummaryStats(),
        jsonText: JSON.stringify(this.workspaceGeneratedPackage() || {}, null, 2),
      };
      model.overviewWarnings = this.workspaceExportWarnings();
      model.sourceMeta = this.sourceMetaText(this.selectedProductSource());
      return model;
    }

    if (this.state.currentLevel === 'general-entries' || this.state.currentLevel === 'products-entries' || this.state.currentLevel === 'materials-entries') {
      const value = this.currentSectionValue();
      const kind = Array.isArray(value) ? 'array' : (isPlainObject(value) ? 'object' : 'overview');
      model.section = {
        id: this.state.activeSectionId || 'section',
        label: friendlySectionLabel(this.state.activeSectionId || 'Section'),
        kind,
      };
      model.sectionValue = value;
      model.sectionValidation = this.currentSectionValidation();
      model.showViewToggle = kind === 'array';
      model.overviewWarnings = [];
      model.sourceMeta = this.sourceMetaText(context?.owner);
      return model;
    }

    model.section = { id: 'overview', label: 'Workspace', kind: 'overview' };
    model.overviewStats = [];
    model.showViewToggle = false;
    return model;
  }

  exportSummaryStats() {
    const generated = this.workspaceGeneratedPackage();
    if (!isPlainObject(generated)) {
      return [];
    }
    const stats = [];
    for (const [key, value] of Object.entries(generated)) {
      if (Array.isArray(value)) {
        stats.push({ label: friendlySectionLabel(key), count: value.length });
      }
    }
    return stats.slice(0, 12);
  }

  arrayActionState() {
    const isEntryLevel = this.state.currentLevel === 'general-entries' || this.state.currentLevel === 'products-entries' || this.state.currentLevel === 'materials-entries';
    if (!isEntryLevel) {
      return {
        canAdd: false,
        canDuplicate: false,
        canDelete: false,
        canMoveUp: false,
        canMoveDown: false,
      };
    }

    const value = this.currentSectionValue();
    if (!Array.isArray(value)) {
      return {
        canAdd: false,
        canDuplicate: false,
        canDelete: false,
        canMoveUp: false,
        canMoveDown: false,
      };
    }

    const index = Number(this.state.selectedEntryRef?.index);
    const hasSelection = Number.isInteger(index) && index >= 0 && index < value.length;
    return {
      canAdd: true,
      canDuplicate: hasSelection,
      canDelete: hasSelection,
      canMoveUp: hasSelection && index > 0,
      canMoveDown: hasSelection && index < value.length - 1,
    };
  }

  renderHeader() {
    this.dom.header.setState({
      activeWorkspace: this.state.activeWorkspace,
      organizations: this.state.organizations,
      currentOrganizationId: this.currentOrganizationId(),
      statusText: this.state.statusText,
    });
  }

  renderBrowser() {
    this.dom.sectionBrowser.update(this.browserModel());
  }

  renderInspector() {
    this.syncInspectorPlacement();

    if (!this.inspectorVisible()) {
      this.dom.inspector.setData({
        section: null,
        entryRef: null,
        entryValue: undefined,
        relationOptions: this.state.relationOptions,
        relationFieldTargets: RELATION_FIELD_TARGETS,
        entryWarnings: [],
      });
      return;
    }

    const context = this.currentEntryContext();
    const section = {
      id: this.state.activeSectionId,
      label: friendlySectionLabel(this.state.activeSectionId),
      kind: Array.isArray(this.currentSectionValue()) ? 'array' : 'object',
    };

    const entryWarnings = (() => {
      if (!context?.owner?.validation || !Array.isArray(this.currentSectionValue())) {
        return [];
      }
      const index = Number(this.state.selectedEntryRef?.index);
      const map = context.owner.validation.sections?.[this.state.activeSectionId]?.entryWarnings || {};
      return Array.isArray(map[index]) ? map[index] : [];
    })();

    this.dom.inspector.setData({
      section,
      entryRef: this.state.selectedEntryRef,
      entryValue: this.selectedEntryValue(),
      relationOptions: this.state.relationOptions,
      relationFieldTargets: RELATION_FIELD_TARGETS,
      entryWarnings,
    });
  }

  selectedEntryValue() {
    const context = this.currentEntryContext();
    if (!context || !context.owner || !isPlainObject(context.owner.data)) {
      return undefined;
    }
    const sectionValue = context.owner.data[context.sectionId];
    if (Array.isArray(sectionValue)) {
      const index = Number(this.state.selectedEntryRef?.index);
      return Number.isInteger(index) ? sectionValue[index] : undefined;
    }
    if (isPlainObject(sectionValue)) {
      if (this.state.selectedEntryRef?.scope === 'section') {
        return sectionValue;
      }
      const key = this.state.selectedEntryRef?.key;
      return typeof key === 'string' ? sectionValue[key] : undefined;
    }
    return undefined;
  }

  syncInspectorPlacement() {
    const placement = this.inspectorVisible() ? 'right' : 'hidden';
    this.dom.paneLayout.setAttribute('inspector-placement', placement);
  }

  refreshAll() {
    this.recomputeDerivedState();
    this.renderHeader();
    this.renderBrowser();
    this.renderInspector();
  }
  async handlePanelAction(actionId) {
    if (actionId === 'new-manufacturer') {
      this.createNewManufacturer();
      return;
    }
    if (actionId === 'open-manufacturer') {
      await this.openManufacturerFile();
      return;
    }
    if (actionId === 'save-manufacturer') {
      await this.saveManufacturer();
      return;
    }
    if (actionId === 'new-product-collection') {
      this.createNewCollection('products');
      return;
    }
    if (actionId === 'new-material-collection') {
      this.createNewCollection('materials');
      return;
    }
    if (actionId === 'open-product-collection-file') {
      await this.openCollectionFile('products');
      return;
    }
    if (actionId === 'open-material-collection-file') {
      await this.openCollectionFile('materials');
      return;
    }
    if (actionId === 'save-product-collection') {
      await this.saveSelectedCollection('products');
      return;
    }
    if (actionId === 'save-material-collection') {
      await this.saveSelectedCollection('materials');
      return;
    }
    if (actionId === 'generate-export') {
      this.refreshExportSnapshot();
      const warnings = this.workspaceExportWarnings();
      this.setStatus(warnings.length > 0
        ? `Generated export with ${warnings.length} warning${warnings.length === 1 ? '' : 's'}.`
        : 'Generated package export.');
      this.renderBrowser();
      return;
    }
    if (actionId === 'download-export') {
      await this.downloadGeneratedExport();
    }
  }

  openSelectedCollection() {
    this.openCollectionAtIndex(Number(this.state.selectedEntryRef?.index));
  }

  openCollectionAtIndex(index) {
    const entries = this.currentListEntries();
    if (!Number.isInteger(index) || index < 0 || index >= entries.length) {
      return;
    }
    const selected = entries[index];
    if (!selected) {
      return;
    }

    if (this.state.activeWorkspace === 'products') {
      this.state.workspace.activeProductSourceId = selected.sourceId || selected.id;
      this.state.currentLevel = 'products-sections';
    } else if (this.state.activeWorkspace === 'materials') {
      this.state.workspace.activeMaterialSourceId = selected.sourceId || selected.id;
      this.state.currentLevel = 'materials-sections';
    }

    this.state.selectedEntryRef = null;
    this.state.activeSectionId = null;
    this.refreshAll();
  }

  openSelectedSection() {
    this.openSectionAtIndex(Number(this.state.selectedEntryRef?.index));
  }

  openSectionAtIndex(index) {
    const entries = this.sectionEntriesForCurrentLevel();
    if (!Number.isInteger(index) || index < 0 || index >= entries.length) {
      return;
    }

    const selected = entries[index];
    if (!selected) {
      return;
    }

    if (selected.id === '__export__' && this.state.activeWorkspace === 'products') {
      this.state.currentLevel = 'products-export';
      this.state.activeSectionId = null;
      this.state.selectedEntryRef = null;
      this.refreshAll();
      return;
    }

    this.state.activeSectionId = selected.id;
    this.state.selectedEntryRef = null;
    if (this.state.currentLevel === 'general-sections') {
      this.state.currentLevel = 'general-entries';
    } else if (this.state.currentLevel === 'products-sections') {
      this.state.currentLevel = 'products-entries';
    } else if (this.state.currentLevel === 'materials-sections') {
      this.state.currentLevel = 'materials-entries';
    }

    this.refreshAll();
  }

  createNewManufacturer() {
    const manufacturer = createSourceDescriptor({
      role: 'manufacturer',
      label: 'Manufacturer source',
      ownerOrgId: this.currentOrganizationId(),
      connectionType: 'local-file',
      fileName: 'manufacturer_info.json',
      sourcePath: 'manufacturer_info.json',
      data: createManufacturerTemplate(),
      isLoaded: true,
      isDirty: true,
      validation: createEmptyValidation(),
    });
    manufacturer.dirty = true;
    this.state.workspace.sources.manufacturer = manufacturer;
    this.state.currentLevel = 'general-sections';
    this.state.activeSectionId = null;
    this.state.selectedEntryRef = null;
    this.setStatus('Created a new manufacturer source template.');
    this.refreshAll();
  }

  createNewCollection(workspace) {
    const collection = makeCollectionRecord(
      workspace,
      createCollectionTemplate(workspace),
      this.currentOrganizationId(),
      null,
      workspace === 'products' ? 'product-collection.json' : 'material-collection.json',
    );
    collection.isDirty = true;
    collection.dirty = true;

    if (workspace === 'products') {
      this.state.workspace.sources.products = collection;
      this.state.workspace.activeProductSourceId = collection.sourceId || collection.id;
      this.state.activeWorkspace = 'products';
      this.state.currentLevel = 'products-sections';
    } else {
      this.state.workspace.sources.materials = [...this.materialSources(), collection];
      this.state.workspace.activeMaterialSourceId = collection.sourceId || collection.id;
      this.state.activeWorkspace = 'materials';
      this.state.currentLevel = 'materials-sections';
    }

    this.state.activeSectionId = null;
    this.state.selectedEntryRef = null;
    this.setStatus(`Created a new ${workspace === 'products' ? 'product' : 'material'} collection.`);
    this.refreshAll();
  }

  async openManufacturerFile() {
    this.state.pendingOpenTarget = { type: 'manufacturer' };
    await this.openJsonPicker();
  }

  async openCollectionFile(workspace) {
    this.state.pendingOpenTarget = { type: 'collection', workspace };
    await this.openJsonPicker();
  }

  async openJsonPicker() {
    try {
      if (typeof window.showOpenFilePicker === 'function') {
        const [handle] = await window.showOpenFilePicker({
          multiple: false,
          types: [
            {
              description: 'JSON files',
              accept: {
                'application/json': ['.json'],
              },
            },
          ],
        });

        if (!handle) {
          return;
        }

        const file = await handle.getFile();
        await this.handleOpenedFile(file, handle);
        return;
      }

      this.dom.openFileInput.click();
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Open failed: ${error.message}`);
    }
  }

  async handlePendingOpenFile(file) {
    await this.handleOpenedFile(file, null);
  }

  async handleOpenedFile(file, handle) {
    const pending = this.state.pendingOpenTarget;
    this.state.pendingOpenTarget = null;

    if (!pending) {
      return;
    }

    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (!isPlainObject(parsed)) {
        throw new Error('Selected JSON must contain one top-level object.');
      }

      if (pending.type === 'manufacturer') {
        const manufacturer = createSourceDescriptor({
          role: 'manufacturer',
          sourceId: this.manufacturerSource()?.sourceId || '',
          label: 'Manufacturer source',
          ownerOrgId: this.currentOrganizationId(),
          connectionType: 'local-file',
          fileHandle: handle,
          fileName: file.name || (handle?.name || 'manufacturer_info.json'),
          sourcePath: file.name || (handle?.name || ''),
          data: parsed,
          isLoaded: true,
          isDirty: false,
          validation: validateDataRoot('general', parsed),
        });
        manufacturer.dirty = false;
        this.state.workspace.sources.manufacturer = manufacturer;
        this.state.activeWorkspace = 'general';
        this.state.currentLevel = 'general-sections';
        this.state.activeSectionId = null;
        this.state.selectedEntryRef = null;
        this.setStatus(`Opened manufacturer source ${manufacturer.fileName}.`);
      }

      if (pending.type === 'collection') {
        const workspace = pending.workspace;
        const collection = makeCollectionRecord(
          workspace,
          parsed,
          this.currentOrganizationId(),
          handle,
          file.name || (handle?.name || `${workspace}-collection.json`),
        );

        if (workspace === 'products') {
          const previous = this.productSource();
          if (previous && previous.collectionId === collection.collectionId) {
            collection.sourceId = previous.sourceId;
          }
          this.state.workspace.sources.products = collection;
          this.state.workspace.activeProductSourceId = collection.sourceId || collection.id;
          this.state.activeWorkspace = 'products';
          this.state.currentLevel = 'products-sections';
        } else {
          const next = [...this.materialSources()];
          const existingIndex = next.findIndex((entry) => entry.collectionId === collection.collectionId || entry.id === collection.id);
          if (existingIndex >= 0) {
            collection.sourceId = next[existingIndex].sourceId || collection.sourceId;
            next[existingIndex] = collection;
          } else {
            next.push(collection);
          }
          this.state.workspace.sources.materials = next;
          this.state.workspace.activeMaterialSourceId = collection.sourceId || collection.id;
          this.state.activeWorkspace = 'materials';
          this.state.currentLevel = 'materials-sections';
        }

        this.state.activeSectionId = null;
        this.state.selectedEntryRef = null;
        this.setStatus(`Opened ${workspace} source ${collection.title}.`);
      }

      this.refreshAll();
    } catch (error) {
      this.setStatus(`Open failed: ${error.message}`);
    }
  }
  async saveManufacturer() {
    const manufacturer = this.manufacturerSource();
    if (!isPlainObject(manufacturer?.data)) {
      this.setStatus('No manufacturer source loaded.');
      return;
    }

    try {
      const text = `${JSON.stringify(manufacturer.data, null, 2)}\n`;
      if (manufacturer.fileHandle && typeof manufacturer.fileHandle.createWritable === 'function') {
        await this.writeToHandle(manufacturer.fileHandle, text);
      } else {
        await this.saveTextAsFile(text, manufacturer.fileName || 'manufacturer_info.json');
      }
      setSourceDirty(manufacturer, false);
      this.setStatus('Manufacturer source saved.');
      this.refreshAll();
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Save manufacturer failed: ${error.message}`);
    }
  }

  async saveSelectedCollection(workspace) {
    const collection = workspace === 'products'
      ? this.selectedProductSource()
      : this.selectedMaterialSource();

    if (!collection) {
      this.setStatus('No collection selected.');
      return;
    }

    try {
      const text = `${JSON.stringify(collection.data, null, 2)}\n`;
      if (collection.fileHandle && typeof collection.fileHandle.createWritable === 'function') {
        await this.writeToHandle(collection.fileHandle, text);
      } else {
        await this.saveTextAsFile(text, collection.fileName || `${workspace}-collection.json`);
      }
      setSourceDirty(collection, false);
      this.setStatus(`${workspace === 'products' ? 'Products' : 'Materials'} source saved.`);
      this.refreshAll();
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Save collection failed: ${error.message}`);
    }
  }

  async downloadGeneratedExport() {
    try {
      const text = `${JSON.stringify(this.workspaceGeneratedPackage() || {}, null, 2)}\n`;
      await this.saveTextAsFile(text, 'configurator-package.json');
      this.setStatus('Generated package exported.');
    } catch (error) {
      if (error?.name === 'AbortError') {
        return;
      }
      this.setStatus(`Export download failed: ${error.message}`);
    }
  }

  async saveTextAsFile(text, suggestedName) {
    if (typeof window.showSaveFilePicker === 'function') {
      const handle = await window.showSaveFilePicker({
        suggestedName,
        types: [
          {
            description: 'JSON files',
            accept: {
              'application/json': ['.json'],
            },
          },
        ],
      });
      if (!handle) {
        return;
      }
      await this.writeToHandle(handle, text);
      return;
    }

    const blob = new Blob([text], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = suggestedName;
    link.click();
    URL.revokeObjectURL(url);
  }

  async writeToHandle(handle, text) {
    const writable = await handle.createWritable();
    await writable.write(text);
    await writable.close();
  }

  applyEntryChange(detail) {
    const context = this.currentEntryContext();
    if (!context || !context.owner || !isPlainObject(context.owner.data)) {
      return;
    }

    const sectionId = context.sectionId;
    if (!sectionId || detail.sectionId !== sectionId) {
      return;
    }

    const nextData = cloneJson(context.owner.data);
    const ref = detail.entryRef || {};
    const value = detail.value;

    if (Array.isArray(nextData[sectionId]) && Number.isInteger(ref.index)) {
      nextData[sectionId][ref.index] = value;
    } else if (isPlainObject(nextData[sectionId])) {
      if (typeof ref.key === 'string') {
        nextData[sectionId][ref.key] = value;
      } else if (ref.scope === 'section') {
        nextData[sectionId] = value;
      }
    }

    context.owner.data = nextData;
    setSourceDirty(context.owner, true);
    this.setStatus(`Edited ${friendlySectionLabel(sectionId)}.`);
    this.refreshAll();
  }

  applyArrayAction(action) {
    const context = this.currentEntryContext();
    if (!context || !context.owner || !isPlainObject(context.owner.data)) {
      return;
    }

    const sectionId = context.sectionId;
    const list = context.owner.data[sectionId];
    if (!Array.isArray(list)) {
      return;
    }

    const index = Number(this.state.selectedEntryRef?.index);
    const hasSelection = Number.isInteger(index) && index >= 0 && index < list.length;

    if (action === 'add') {
      const template = {
        id: `${slugify(sectionId, 'entry')}-${list.length + 1}`,
        title: `New ${friendlySectionLabel(sectionId)}`,
      };
      template.id = ensureUniqueEntryId(list, template.id);
      list.push(template);
      this.state.selectedEntryRef = { index: list.length - 1 };
    } else if (action === 'duplicate') {
      if (!hasSelection) return;
      const next = cloneJson(list[index]);
      if (isPlainObject(next) && next.id) {
        next.id = ensureUniqueEntryId(list, `${next.id}-copy`);
      }
      list.splice(index + 1, 0, next);
      this.state.selectedEntryRef = { index: index + 1 };
    } else if (action === 'delete') {
      if (!hasSelection) return;
      if (!window.confirm(`Delete selected entry from ${friendlySectionLabel(sectionId)}?`)) {
        return;
      }
      list.splice(index, 1);
      this.state.selectedEntryRef = list.length > 0 ? { index: Math.max(0, Math.min(index, list.length - 1)) } : null;
    } else if (action === 'move-up') {
      if (!hasSelection || index <= 0) return;
      const temp = list[index - 1];
      list[index - 1] = list[index];
      list[index] = temp;
      this.state.selectedEntryRef = { index: index - 1 };
    } else if (action === 'move-down') {
      if (!hasSelection || index >= list.length - 1) return;
      const temp = list[index + 1];
      list[index + 1] = list[index];
      list[index] = temp;
      this.state.selectedEntryRef = { index: index + 1 };
    }

    context.owner.data = { ...context.owner.data, [sectionId]: list };
    setSourceDirty(context.owner, true);
    this.refreshAll();
  }
}

if (!customElements.get('open-configurator-manager')) {
  customElements.define('open-configurator-manager', OpenConfiguratorManagerElement);
}

export { OpenConfiguratorManagerElement };

