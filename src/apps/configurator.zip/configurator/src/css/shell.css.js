export const configuratorShellStyles = `
  :host {
    display: block;
    color: #111827;
    font-family: "Segoe UI", Tahoma, sans-serif;
    background: #eef2f7;
  }

  * {
    box-sizing: border-box;
  }

  .app-shell {
    width: 100%;
    height: min(100dvh, 100vh);
    min-height: 680px;
    background: #eef2f7;
    overflow: hidden;
    display: grid;
    grid-template-rows: auto minmax(0, 1fr);
  }

  .workspace {
    width: min(100%, 1320px);
    margin-inline: auto;
    min-height: 0;
    display: grid;
    overflow: hidden;
  }

  .workspace > open-pane-layout {
    min-height: 0;
    height: 100%;
    display: block;
  }

  open-configurator-section-browser {
    min-height: 0;
    height: 100%;
    padding: 0.9rem;
    overflow: hidden;
  }

  open-configurator-inspector {
    display: block;
    min-height: 0;
    height: 100%;
    border-left: 1px solid #dbe3ec;
    background: #ffffff;
    overflow: hidden;
  }

  @media (max-width: 1080px) {
    .app-shell {
      width: 100%;
    }

    .workspace {
      width: 100%;
    }

    open-configurator-section-browser {
      padding: 0.8rem;
    }
  }

  @media (max-width: 760px) {
    .app-shell {
      min-height: 100dvh;
    }
    open-configurator-section-browser {
      padding: 0.65rem;
    }
  }
`;
